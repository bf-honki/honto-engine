HonTo Engine SDK Setup

1. Run HonToEngine-SDK-Setup.exe
2. Restart Visual Studio
3. Create a game with:
   %HONTO_SDK_ROOT%\bin\New-HonToProject.ps1
4. Or create a Visual Studio library project with:
   %HONTO_SDK_ROOT%\bin\New-HonToVsProject.ps1
