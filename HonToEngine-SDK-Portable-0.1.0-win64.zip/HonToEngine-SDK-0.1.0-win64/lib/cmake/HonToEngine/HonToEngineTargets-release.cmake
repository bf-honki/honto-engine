#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "HonTo::Engine" for configuration "Release"
set_property(TARGET HonTo::Engine APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(HonTo::Engine PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/honto_engine.lib"
  )

list(APPEND _cmake_import_check_targets HonTo::Engine )
list(APPEND _cmake_import_check_files_for_HonTo::Engine "${_IMPORT_PREFIX}/lib/honto_engine.lib" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
