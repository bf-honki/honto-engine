#pragma once

#include "Application.h"
#include "Audio.h"
#include "Input.h"
#include "Level.h"
#include "Raycast.h"
#include "SceneGraph.h"
#include "TileMap.h"
#include "Texture.h"

#include <algorithm>
#include <cctype>
#include <cstddef>
#include <cstdint>
#include <cmath>
#include <functional>
#include <initializer_list>
#include <iostream>
#include <memory>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace HonTo
{
    using Vec2 = honto::Vec2;
    using Color = honto::Color;
    using Key = honto::KeyCode;
    using Mouse = honto::MouseButton;
    using Level = honto::LevelDocument;
    using LevelEntity = honto::LevelEntity;
    using Texture = honto::Texture;

    namespace detail
    {
        class FrameNode final : public honto::Node
        {
        public:
            bool Init() override
            {
                return true;
            }

            void SetColor(Color color)
            {
                m_Color = color;
            }

            Color GetColor() const
            {
                return m_Color;
            }

            void SetThickness(int thickness)
            {
                m_Thickness = thickness;
            }

            void Draw(honto::Renderer2D& renderer, const Vec2& worldPosition, const Vec2& worldScale) override
            {
                renderer.DrawRectOutline(worldPosition, GetContentSize() * worldScale, m_Color, m_Thickness);
            }

        private:
            Color m_Color { 255, 255, 255, 255 };
            int m_Thickness = 1;
        };

        class BuiltGame final : public honto::Game
        {
        public:
            struct BuiltWindow
            {
                honto::AppConfig config {};
                bool closeStopsGame = false;
                std::function<std::unique_ptr<honto::Scene>()> sceneFactory;
            };

            BuiltGame(
                honto::AppConfig config,
                std::function<std::unique_ptr<honto::Scene>()> sceneFactory,
                std::vector<BuiltWindow> additionalWindows
            )
                : m_Config(std::move(config)),
                  m_SceneFactory(std::move(sceneFactory)),
                  m_AdditionalWindows(std::move(additionalWindows))
            {
            }

            honto::AppConfig GetConfig() const override
            {
                return m_Config;
            }

            std::unique_ptr<honto::Scene> CreateInitialScene() override
            {
                if (m_SceneFactory)
                {
                    return m_SceneFactory();
                }

                return nullptr;
            }

            std::vector<honto::WindowStartup> CreateAdditionalWindows() override
            {
                std::vector<honto::WindowStartup> windows;
                windows.reserve(m_AdditionalWindows.size());

                for (const BuiltWindow& builtWindow : m_AdditionalWindows)
                {
                    honto::WindowStartup startup;
                    startup.config = builtWindow.config;
                    startup.closeStopsGame = builtWindow.closeStopsGame;
                    startup.createScene = builtWindow.sceneFactory;
                    windows.push_back(std::move(startup));
                }

                return windows;
            }

        private:
            honto::AppConfig m_Config {};
            std::function<std::unique_ptr<honto::Scene>()> m_SceneFactory;
            std::vector<BuiltWindow> m_AdditionalWindows;
        };

        inline Vec2 Lerp(const Vec2& from, const Vec2& to, float t)
        {
            return {
                from.x + ((to.x - from.x) * t),
                from.y + ((to.y - from.y) * t)
            };
        }

        inline Color Lerp(Color from, Color to, float t)
        {
            const auto blend = [t](std::uint8_t start, std::uint8_t end)
            {
                return static_cast<std::uint8_t>(static_cast<float>(start) + ((static_cast<float>(end) - static_cast<float>(start)) * t));
            };

            return {
                blend(from.r, to.r),
                blend(from.g, to.g),
                blend(from.b, to.b),
                blend(from.a, to.a)
            };
        }
    }

    inline Color RGBA(std::uint8_t r, std::uint8_t g, std::uint8_t b, std::uint8_t a = 255)
    {
        return { r, g, b, a };
    }

    inline void Print(const std::string& text)
    {
        std::cout << text << '\n';
    }

    using Transition = honto::SceneTransition;

    inline Transition Fade(float seconds = 0.5f, Color color = Color { 0, 0, 0, 255 })
    {
        Transition transition;
        transition.type = Transition::Type::Fade;
        transition.duration = std::max(0.05f, seconds);
        transition.color = color;
        return transition;
    }

    class Actor;
    class Animation;
    class FrameAnimation;
    class ParticleActor;
    class RaycastActor;
    class Stage;
    class TileMapActor;

    inline std::shared_ptr<Texture> LoadTexture(const std::string& path)
    {
        return Texture::LoadShared(path);
    }

    inline std::shared_ptr<Texture> CheckerTexture(
        int width,
        int height,
        Color a,
        Color b,
        int cellSize = 8
    )
    {
        return Texture::CreateCheckerboard(width, height, a, b, cellSize);
    }

    inline std::shared_ptr<Texture> FrameSheetTexture(
        int frameWidth,
        int frameHeight,
        const std::vector<Color>& frameColors,
        int columns = 0
    )
    {
        return Texture::CreateFrameSheet(frameWidth, frameHeight, frameColors, columns);
    }

    inline bool PlaySound(const std::string& path, bool loop = false)
    {
        return honto::Audio::PlayWav(path, loop);
    }

    inline bool PlayAlias(const std::string& alias, bool loop = false)
    {
        return honto::Audio::PlayAlias(alias, loop);
    }

    inline bool PlayOnBus(const std::string& bus, const std::string& path, bool loop = false)
    {
        return honto::Audio::PlayOnBus(bus, path, loop);
    }

    inline bool PlayMusic(const std::string& path, bool loop = true)
    {
        return honto::Audio::PlayMusic(path, loop);
    }

    inline bool PlayEffect(const std::string& path)
    {
        return honto::Audio::PlayEffect(path);
    }

    inline void StopAudio()
    {
        honto::Audio::Stop();
    }

    inline void StopAudioBus(const std::string& bus)
    {
        honto::Audio::StopBus(bus);
    }

    inline void SetMasterVolume(float volume)
    {
        honto::Audio::SetMasterVolume(volume);
    }

    inline float MasterVolume()
    {
        return honto::Audio::GetMasterVolume();
    }

    inline void SetBusVolume(const std::string& bus, float volume)
    {
        honto::Audio::SetBusVolume(bus, volume);
    }

    inline float BusVolume(const std::string& bus)
    {
        return honto::Audio::GetBusVolume(bus);
    }

    inline void PlayTone(int frequency, int durationMs)
    {
        honto::Audio::PlayTone(frequency, durationMs);
    }

    inline Level LoadLevel(const std::string& path)
    {
        Level level;
        honto::LevelFile::Load(path, level);
        return level;
    }

    inline bool SaveLevel(const std::string& path, const Level& level)
    {
        return honto::LevelFile::Save(path, level);
    }

    inline const LevelEntity* FindLevelEntity(const Level& level, const std::string& name)
    {
        return honto::FindLevelEntity(level, name);
    }

    template <typename Derived, typename TNode>
    class Chain
    {
    public:
        explicit Chain(std::shared_ptr<TNode> node = nullptr)
            : m_Node(std::move(node))
        {
        }

        Derived& At(float x, float y)
        {
            if (m_Node != nullptr)
            {
                m_Node->SetPosition(x, y);
            }

            return static_cast<Derived&>(*this);
        }

        Derived& At(const Vec2& position)
        {
            if (m_Node != nullptr)
            {
                m_Node->SetPosition(position);
            }

            return static_cast<Derived&>(*this);
        }

        Derived& Size(float width, float height)
        {
            if (m_Node != nullptr)
            {
                m_Node->SetContentSize(width, height);
            }

            return static_cast<Derived&>(*this);
        }

        Derived& Size(const Vec2& size)
        {
            if (m_Node != nullptr)
            {
                m_Node->SetContentSize(size);
            }

            return static_cast<Derived&>(*this);
        }

        Derived& Scale(float uniformScale)
        {
            if (m_Node != nullptr)
            {
                m_Node->SetScale(uniformScale);
            }

            return static_cast<Derived&>(*this);
        }

        Derived& Scale(float x, float y)
        {
            if (m_Node != nullptr)
            {
                m_Node->SetScale({ x, y });
            }

            return static_cast<Derived&>(*this);
        }

        Derived& Show(bool visible = true)
        {
            if (m_Node != nullptr)
            {
                m_Node->SetVisible(visible);
            }

            return static_cast<Derived&>(*this);
        }

        Derived& Hide()
        {
            return Show(false);
        }

        Derived& UpdateEveryFrame()
        {
            if (m_Node != nullptr)
            {
                m_Node->ScheduleUpdate();
            }

            return static_cast<Derived&>(*this);
        }

        Derived& Z(int zOrder)
        {
            m_ZOrder = zOrder;
            return static_cast<Derived&>(*this);
        }

        Derived& hontoAt(float x, float y)
        {
            return At(x, y);
        }

        Derived& hontoAt(const Vec2& position)
        {
            return At(position);
        }

        Derived& hontoSize(float width, float height)
        {
            return Size(width, height);
        }

        Derived& hontoSize(const Vec2& size)
        {
            return Size(size);
        }

        Derived& hontoScale(float uniformScale)
        {
            return Scale(uniformScale);
        }

        Derived& hontoScale(float x, float y)
        {
            return Scale(x, y);
        }

        Derived& hontoShow(bool visible = true)
        {
            return Show(visible);
        }

        Derived& hontoHide()
        {
            return Hide();
        }

        Derived& hontoUpdateEveryFrame()
        {
            return UpdateEveryFrame();
        }

        Derived& hontoLayer(int zOrder)
        {
            return Z(zOrder);
        }

        std::shared_ptr<TNode> Share() const
        {
            return m_Node;
        }

        int GetZOrder() const
        {
            return m_ZOrder;
        }

    protected:
        std::shared_ptr<TNode> m_Node;
        int m_ZOrder = 0;
    };

    class Sprite final : public Chain<Sprite, honto::Sprite>
    {
    public:
        explicit Sprite(std::shared_ptr<honto::Sprite> node = honto::Sprite::CreateSolid({ 16.0f, 16.0f }, RGBA(255, 255, 255)))
            : Chain(std::move(node))
        {
        }

        Sprite& Paint(Color color)
        {
            if (m_Node != nullptr)
            {
                m_Node->SetColor(color);
            }

            return *this;
        }

        Sprite& Paint(std::uint8_t r, std::uint8_t g, std::uint8_t b, std::uint8_t a = 255)
        {
            return Paint(RGBA(r, g, b, a));
        }

        Sprite& UseTexture(const std::shared_ptr<Texture>& texture)
        {
            if (m_Node != nullptr)
            {
                m_Node->SetTexture(texture);
            }

            return *this;
        }

        Sprite& hontoPaint(Color color)
        {
            return Paint(color);
        }

        Sprite& hontoPaint(std::uint8_t r, std::uint8_t g, std::uint8_t b, std::uint8_t a = 255)
        {
            return Paint(r, g, b, a);
        }

        Sprite& hontoUseTexture(const std::shared_ptr<Texture>& texture)
        {
            return UseTexture(texture);
        }
    };

    class Layer final : public Chain<Layer, honto::LayerColor>
    {
    public:
        explicit Layer(std::shared_ptr<honto::LayerColor> node = honto::LayerColor::Create(RGBA(255, 255, 255), 16.0f, 16.0f))
            : Chain(std::move(node))
        {
        }

        Layer& Paint(Color color)
        {
            if (m_Node != nullptr)
            {
                m_Node->SetColor(color);
            }

            return *this;
        }

        Layer& Paint(std::uint8_t r, std::uint8_t g, std::uint8_t b, std::uint8_t a = 255)
        {
            return Paint(RGBA(r, g, b, a));
        }

        Layer& hontoPaint(Color color)
        {
            return Paint(color);
        }

        Layer& hontoPaint(std::uint8_t r, std::uint8_t g, std::uint8_t b, std::uint8_t a = 255)
        {
            return Paint(r, g, b, a);
        }
    };

    class Frame final : public Chain<Frame, detail::FrameNode>
    {
    public:
        Frame()
            : Chain(std::make_shared<detail::FrameNode>())
        {
            if (m_Node != nullptr)
            {
                m_Node->Init();
            }
        }

        Frame& Paint(Color color)
        {
            if (m_Node != nullptr)
            {
                m_Node->SetColor(color);
            }

            return *this;
        }

        Frame& Paint(std::uint8_t r, std::uint8_t g, std::uint8_t b, std::uint8_t a = 255)
        {
            return Paint(RGBA(r, g, b, a));
        }

        Frame& Thickness(int thickness)
        {
            if (m_Node != nullptr)
            {
                m_Node->SetThickness(thickness);
            }

            return *this;
        }

        Frame& hontoPaint(Color color)
        {
            return Paint(color);
        }

        Frame& hontoPaint(std::uint8_t r, std::uint8_t g, std::uint8_t b, std::uint8_t a = 255)
        {
            return Paint(r, g, b, a);
        }

        Frame& hontoThickness(int thickness)
        {
            return Thickness(thickness);
        }
    };

    inline Sprite Box(float width, float height, Color color)
    {
        return Sprite(honto::Sprite::CreateSolid({ width, height }, color)).Size(width, height).Paint(color);
    }

    inline Sprite Image(const std::shared_ptr<Texture>& texture, float width, float height, Color tint = RGBA(255, 255, 255))
    {
        return Sprite(honto::Sprite::CreateTextured({ width, height }, texture, tint)).Size(width, height).Paint(tint);
    }

    inline Sprite Image(const std::string& path, float width, float height, Color tint = RGBA(255, 255, 255))
    {
        return Image(LoadTexture(path), width, height, tint);
    }

    inline Layer Fill(float width, float height, Color color)
    {
        return Layer(honto::LayerColor::Create(color, width, height)).Size(width, height).Paint(color);
    }

    inline Layer Fill(const Vec2& size, Color color)
    {
        return Fill(size.x, size.y, color);
    }

    inline Frame Outline(float width, float height, Color color, int thickness = 1)
    {
        return Frame().Size(width, height).Paint(color).Thickness(thickness);
    }

    inline Vec2 VisibleSize()
    {
        return honto::Director::Get().GetVisibleSize();
    }

    inline bool Pressing(Key key)
    {
        return honto::Input::IsKeyDown(key);
    }

    inline bool Pressed(Key key)
    {
        return honto::Input::IsKeyPressed(key);
    }

    inline Vec2 MousePosition()
    {
        return honto::Input::MousePosition();
    }

    inline bool HasMouse()
    {
        return honto::Input::HasMouse();
    }

    inline bool MouseDown(Mouse button)
    {
        return honto::Input::IsMouseDown(button);
    }

    inline bool MousePressed(Mouse button)
    {
        return honto::Input::IsMousePressed(button);
    }

    class Scene : public honto::CodeScene
    {
    public:
        virtual bool Setup()
        {
            return true;
        }

        bool Init() override
        {
            return Setup();
        }

        void EveryFrame()
        {
            ScheduleUpdate();
        }

        void hontoEveryFrame()
        {
            EveryFrame();
        }

        template <typename TNode>
        std::shared_ptr<TNode> Add(const std::shared_ptr<TNode>& node, int zOrder = 0)
        {
            AddChild(node, zOrder);
            return node;
        }

        template <typename TChain>
        auto Add(const TChain& chain) -> decltype(chain.Share())
        {
            auto node = chain.Share();
            AddChild(node, chain.GetZOrder());
            return node;
        }

        template <typename TNode>
        std::shared_ptr<TNode> hontoAdd(const std::shared_ptr<TNode>& node, int zOrder = 0)
        {
            return Add(node, zOrder);
        }

        template <typename TChain>
        auto hontoAdd(const TChain& chain) -> decltype(chain.Share())
        {
            return Add(chain);
        }

        template <typename TScene>
        void Go()
        {
            Go(std::make_unique<TScene>());
        }

        template <typename TScene>
        void Go(const Transition& transition)
        {
            Go(std::make_unique<TScene>(), transition);
        }

        void Go(std::unique_ptr<honto::Scene> scene, const Transition& transition = {})
        {
            honto::Director::Get().ReplaceScene(std::move(scene), transition);
        }

        template <typename TScene>
        void hontoGo()
        {
            Go<TScene>();
        }

        template <typename TScene>
        void hontoGo(const Transition& transition)
        {
            Go<TScene>(transition);
        }

        void hontoGo(std::unique_ptr<honto::Scene> scene, const Transition& transition = {})
        {
            Go(std::move(scene), transition);
        }
    };

    namespace detail
    {
        struct StageState;
        std::function<std::unique_ptr<honto::Scene>()> MakeScriptSceneFactory(std::function<void(Stage&)> setup);

        inline std::string Trim(const std::string& text)
        {
            std::size_t first = 0;
            while (first < text.size() && std::isspace(static_cast<unsigned char>(text[first])) != 0)
            {
                ++first;
            }

            std::size_t last = text.size();
            while (last > first && std::isspace(static_cast<unsigned char>(text[last - 1])) != 0)
            {
                --last;
            }

            return text.substr(first, last - first);
        }

        inline std::string ToLowerAscii(std::string text)
        {
            for (char& ch : text)
            {
                ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
            }

            return text;
        }

        inline std::string NormalizeCommandName(const std::string& name)
        {
            std::string normalized = ToLowerAscii(Trim(name));
            if (normalized.rfind("honto", 0) == 0)
            {
                normalized.erase(0, 5);
            }

            return normalized;
        }

        inline std::string Unquote(std::string text)
        {
            text = Trim(text);
            if (text.size() >= 2 &&
                ((text.front() == '"' && text.back() == '"') ||
                 (text.front() == '\'' && text.back() == '\'')))
            {
                text = text.substr(1, text.size() - 2);
            }

            std::string output;
            output.reserve(text.size());

            bool escaping = false;
            for (char ch : text)
            {
                if (escaping)
                {
                    switch (ch)
                    {
                    case 'n':
                        output.push_back('\n');
                        break;
                    case 'r':
                        output.push_back('\r');
                        break;
                    case 't':
                        output.push_back('\t');
                        break;
                    case '\\':
                    case '"':
                    case '\'':
                        output.push_back(ch);
                        break;
                    default:
                        output.push_back(ch);
                        break;
                    }

                    escaping = false;
                    continue;
                }

                if (ch == '\\')
                {
                    escaping = true;
                    continue;
                }

                output.push_back(ch);
            }

            if (escaping)
            {
                output.push_back('\\');
            }

            return output;
        }

        inline std::string NormalizeNumberToken(const std::string& token)
        {
            std::string text = Trim(token);
            if (!text.empty() && (text.back() == 'f' || text.back() == 'F'))
            {
                text.pop_back();
            }

            return text;
        }

        inline std::vector<std::string> SplitCommandArguments(const std::string& argumentsText)
        {
            std::vector<std::string> result;
            std::string current;
            int nesting = 0;
            char quote = 0;
            bool escaping = false;

            for (char ch : argumentsText)
            {
                if (quote != 0)
                {
                    current.push_back(ch);
                    if (escaping)
                    {
                        escaping = false;
                        continue;
                    }

                    if (ch == '\\')
                    {
                        escaping = true;
                        continue;
                    }

                    if (ch == quote)
                    {
                        quote = 0;
                    }

                    continue;
                }

                if (ch == '"' || ch == '\'')
                {
                    quote = ch;
                    current.push_back(ch);
                    continue;
                }

                if (ch == '(' || ch == '[' || ch == '{')
                {
                    ++nesting;
                    current.push_back(ch);
                    continue;
                }

                if (ch == ')' || ch == ']' || ch == '}')
                {
                    if (nesting > 0)
                    {
                        --nesting;
                    }

                    current.push_back(ch);
                    continue;
                }

                if (ch == ',' && nesting == 0)
                {
                    result.push_back(Trim(current));
                    current.clear();
                    continue;
                }

                current.push_back(ch);
            }

            if (!current.empty() || !result.empty())
            {
                result.push_back(Trim(current));
            }

            if (result.size() == 1 && result.front().empty())
            {
                result.clear();
            }

            return result;
        }

        struct ParsedCommand
        {
            std::string name;
            std::vector<std::string> args;
            bool valid = false;
        };

        inline ParsedCommand ParseCommand(const std::string& commandText)
        {
            ParsedCommand parsed;
            const std::string trimmed = Trim(commandText);
            if (trimmed.empty())
            {
                return parsed;
            }

            const std::size_t openParen = trimmed.find('(');
            if (openParen == std::string::npos)
            {
                parsed.name = trimmed;
                parsed.valid = true;
                return parsed;
            }

            const std::size_t closeParen = trimmed.rfind(')');
            if (closeParen == std::string::npos || closeParen < openParen)
            {
                return parsed;
            }

            if (!Trim(trimmed.substr(closeParen + 1)).empty())
            {
                return parsed;
            }

            parsed.name = Trim(trimmed.substr(0, openParen));
            parsed.args = SplitCommandArguments(trimmed.substr(openParen + 1, closeParen - openParen - 1));
            parsed.valid = !parsed.name.empty();
            return parsed;
        }

        inline bool TryParseFloat(const std::string& token, float& value)
        {
            try
            {
                const std::string normalized = NormalizeNumberToken(Unquote(token));
                std::size_t parsedLength = 0;
                value = std::stof(normalized, &parsedLength);
                return parsedLength == normalized.size();
            }
            catch (...)
            {
                return false;
            }
        }

        inline bool TryParseInt(const std::string& token, int& value)
        {
            try
            {
                const std::string normalized = NormalizeNumberToken(Unquote(token));
                std::size_t parsedLength = 0;
                value = std::stoi(normalized, &parsedLength);
                return parsedLength == normalized.size();
            }
            catch (...)
            {
                return false;
            }
        }

        inline bool TryParseBool(const std::string& token, bool& value)
        {
            const std::string normalized = ToLowerAscii(Unquote(token));
            if (normalized == "true" || normalized == "1" || normalized == "yes" || normalized == "on")
            {
                value = true;
                return true;
            }

            if (normalized == "false" || normalized == "0" || normalized == "no" || normalized == "off")
            {
                value = false;
                return true;
            }

            return false;
        }

        inline bool TryParseChar(const std::string& token, char& value)
        {
            const std::string normalized = Unquote(token);
            if (normalized.size() != 1)
            {
                return false;
            }

            value = normalized.front();
            return true;
        }

        inline bool TryParseKey(const std::string& token, Key& value)
        {
            std::string normalized = ToLowerAscii(Unquote(token));
            const std::string prefixA = "honto::hontokey::";
            const std::string prefixB = "hontokey::";
            const std::string prefixC = "key::";
            if (normalized.rfind(prefixA, 0) == 0)
            {
                normalized.erase(0, prefixA.size());
            }
            else if (normalized.rfind(prefixB, 0) == 0)
            {
                normalized.erase(0, prefixB.size());
            }
            else if (normalized.rfind(prefixC, 0) == 0)
            {
                normalized.erase(0, prefixC.size());
            }

            if (normalized == "tab")
            {
                value = Key::Tab;
                return true;
            }
            if (normalized == "left")
            {
                value = Key::Left;
                return true;
            }
            if (normalized == "right")
            {
                value = Key::Right;
                return true;
            }
            if (normalized == "up")
            {
                value = Key::Up;
                return true;
            }
            if (normalized == "down")
            {
                value = Key::Down;
                return true;
            }
            if (normalized == "escape" || normalized == "esc")
            {
                value = Key::Escape;
                return true;
            }
            if (normalized == "enter" || normalized == "return")
            {
                value = Key::Enter;
                return true;
            }
            if (normalized == "shift")
            {
                value = Key::Shift;
                return true;
            }
            if (normalized == "f1")
            {
                value = Key::F1;
                return true;
            }
            if (normalized == "f2")
            {
                value = Key::F2;
                return true;
            }
            if (normalized == "f3")
            {
                value = Key::F3;
                return true;
            }
            if (normalized == "f4")
            {
                value = Key::F4;
                return true;
            }
            if (normalized == "f5")
            {
                value = Key::F5;
                return true;
            }
            if (normalized == "space")
            {
                value = Key::Space;
                return true;
            }
            if (normalized == "a")
            {
                value = Key::A;
                return true;
            }
            if (normalized == "d")
            {
                value = Key::D;
                return true;
            }
            if (normalized == "e")
            {
                value = Key::E;
                return true;
            }
            if (normalized == "m")
            {
                value = Key::M;
                return true;
            }
            if (normalized == "q")
            {
                value = Key::Q;
                return true;
            }
            if (normalized == "s")
            {
                value = Key::S;
                return true;
            }
            if (normalized == "w")
            {
                value = Key::W;
                return true;
            }

            return false;
        }

        inline bool TryParseColorComponent(const std::string& token, std::uint8_t& value)
        {
            int parsed = 0;
            if (!TryParseInt(token, parsed))
            {
                return false;
            }

            value = static_cast<std::uint8_t>(std::clamp(parsed, 0, 255));
            return true;
        }

        inline bool TryParseColorToken(const std::string& token, Color& color)
        {
            const ParsedCommand parsed = ParseCommand(token);
            if (!parsed.valid)
            {
                return false;
            }

            const std::string name = NormalizeCommandName(parsed.name);
            if (name != "rgba" && name != "color")
            {
                return false;
            }

            if (parsed.args.size() != 3 && parsed.args.size() != 4)
            {
                return false;
            }

            std::uint8_t r = 255;
            std::uint8_t g = 255;
            std::uint8_t b = 255;
            std::uint8_t a = 255;

            if (!TryParseColorComponent(parsed.args[0], r) ||
                !TryParseColorComponent(parsed.args[1], g) ||
                !TryParseColorComponent(parsed.args[2], b))
            {
                return false;
            }

            if (parsed.args.size() == 4 && !TryParseColorComponent(parsed.args[3], a))
            {
                return false;
            }

            color = RGBA(r, g, b, a);
            return true;
        }

        inline bool TryParseColor(
            const std::vector<std::string>& args,
            std::size_t index,
            std::size_t remainingColors,
            Color& color,
            std::size_t& consumed)
        {
            consumed = 0;
            if (index >= args.size())
            {
                return false;
            }

            if (TryParseColorToken(args[index], color))
            {
                consumed = 1;
                return true;
            }

            const std::size_t remainingArgs = args.size() - index;
            std::size_t stride = 0;
            if (remainingColors > 0)
            {
                if (remainingArgs == remainingColors * 3)
                {
                    stride = 3;
                }
                else if (remainingArgs == remainingColors * 4)
                {
                    stride = 4;
                }
            }

            if (stride == 0)
            {
                if (remainingArgs >= 4)
                {
                    stride = 4;
                }
                else if (remainingArgs >= 3)
                {
                    stride = 3;
                }
                else
                {
                    return false;
                }
            }

            std::uint8_t r = 255;
            std::uint8_t g = 255;
            std::uint8_t b = 255;
            std::uint8_t a = 255;
            if (!TryParseColorComponent(args[index], r) ||
                !TryParseColorComponent(args[index + 1], g) ||
                !TryParseColorComponent(args[index + 2], b))
            {
                return false;
            }

            if (stride == 4 && !TryParseColorComponent(args[index + 3], a))
            {
                return false;
            }

            color = RGBA(r, g, b, a);
            consumed = stride;
            return true;
        }

        inline bool TryParseColors(
            const std::vector<std::string>& args,
            std::size_t colorCount,
            std::vector<Color>& colors)
        {
            colors.clear();
            std::size_t index = 0;
            std::size_t remainingColors = colorCount;
            while (remainingColors > 0)
            {
                Color color {};
                std::size_t consumed = 0;
                if (!TryParseColor(args, index, remainingColors, color, consumed))
                {
                    colors.clear();
                    return false;
                }

                colors.push_back(color);
                index += consumed;
                --remainingColors;
            }

            return index == args.size();
        }

        inline bool TryParseLooseColor(
            const std::vector<std::string>& args,
            std::size_t index,
            Color& color,
            std::size_t& consumed)
        {
            consumed = 0;
            if (index >= args.size())
            {
                return false;
            }

            if (TryParseColorToken(args[index], color))
            {
                consumed = 1;
                return true;
            }

            std::uint8_t r = 255;
            std::uint8_t g = 255;
            std::uint8_t b = 255;
            std::uint8_t a = 255;

            if ((args.size() - index) >= 4 &&
                TryParseColorComponent(args[index], r) &&
                TryParseColorComponent(args[index + 1], g) &&
                TryParseColorComponent(args[index + 2], b) &&
                TryParseColorComponent(args[index + 3], a))
            {
                color = RGBA(r, g, b, a);
                consumed = 4;
                return true;
            }

            if ((args.size() - index) >= 3 &&
                TryParseColorComponent(args[index], r) &&
                TryParseColorComponent(args[index + 1], g) &&
                TryParseColorComponent(args[index + 2], b))
            {
                color = RGBA(r, g, b, 255);
                consumed = 3;
                return true;
            }

            return false;
        }

        inline std::vector<std::string> ParseMapRows(const std::string& token)
        {
            std::string normalized = Unquote(token);
            std::string expanded;
            expanded.reserve(normalized.size());

            for (std::size_t index = 0; index < normalized.size(); ++index)
            {
                if (normalized[index] == '\\' &&
                    (index + 1) < normalized.size() &&
                    normalized[index + 1] == 'n')
                {
                    expanded.push_back('\n');
                    ++index;
                    continue;
                }

                if (normalized[index] != '\r')
                {
                    expanded.push_back(normalized[index]);
                }
            }

            std::vector<std::string> rows;
            std::string current;
            for (char ch : expanded)
            {
                if (ch == '\n' || ch == '|')
                {
                    rows.push_back(current);
                    current.clear();
                    continue;
                }

                current.push_back(ch);
            }

            if (!current.empty() || rows.empty())
            {
                rows.push_back(current);
            }

            return rows;
        }

        struct ActorState
        {
            std::shared_ptr<honto::Node> node;
            std::weak_ptr<StageState> stage;
            std::string name;
            Vec2 velocity {};
            bool physicsAttached = false;
            bool movesByVelocity = false;
            bool usesGravity = false;
            float gravityScale = 1.0f;
            bool hasGround = false;
            float groundY = 0.0f;
            float groundBounce = 0.0f;
            bool onGround = false;
            std::weak_ptr<honto::TileMap> collisionMap;
        };

        struct StageState
        {
            std::unordered_map<std::string, std::shared_ptr<ActorState>> namedActors;
            std::unordered_map<std::string, std::shared_ptr<honto::TileMap>> namedTileMaps;
            std::vector<std::function<void(float)>> updates;
            HonTo::Scene* scene = nullptr;
            std::size_t nextAnonymousId = 1;
            Vec2 gravity { 0.0f, 0.0f };
        };

        class ScriptScene final : public HonTo::Scene
        {
        public:
            explicit ScriptScene(std::function<void(Stage&)> setup)
                : m_Setup(std::move(setup)),
                  m_State(std::make_shared<StageState>())
            {
            }

            bool Setup() override;
            void Update(float deltaTime) override;

        private:
            std::function<void(Stage&)> m_Setup;
            std::shared_ptr<StageState> m_State;
        };
    }

    class Actor
    {
    public:
        Actor() = default;

        explicit Actor(std::shared_ptr<detail::ActorState> state)
            : m_State(std::move(state))
        {
        }

        explicit operator bool() const
        {
            return Node() != nullptr;
        }

        std::string Name() const
        {
            if (m_State == nullptr)
            {
                return {};
            }

            return m_State->name;
        }

        Vec2 Position() const
        {
            if (const auto node = Node())
            {
                return node->GetPosition();
            }

            return {};
        }

        Vec2 Size() const
        {
            if (const auto node = Node())
            {
                return node->GetContentSize();
            }

            return {};
        }

        Vec2 ScaleValue() const
        {
            if (const auto node = Node())
            {
                return node->GetScale();
            }

            return { 1.0f, 1.0f };
        }

        Color Tint() const
        {
            if (const auto sprite = std::dynamic_pointer_cast<honto::Sprite>(Node()))
            {
                return sprite->GetColor();
            }

            if (const auto layer = std::dynamic_pointer_cast<honto::LayerColor>(Node()))
            {
                return layer->GetColor();
            }

            if (const auto frame = std::dynamic_pointer_cast<detail::FrameNode>(Node()))
            {
                return frame->GetColor();
            }

            if (const auto label = std::dynamic_pointer_cast<honto::Label>(Node()))
            {
                return label->GetColor();
            }

            if (const auto bar = std::dynamic_pointer_cast<honto::ProgressBar>(Node()))
            {
                return bar->GetFillColor();
            }

            if (const auto button = std::dynamic_pointer_cast<honto::Button>(Node()))
            {
                return button->GetNormalColor();
            }

            return RGBA(255, 255, 255);
        }

        Vec2 Velocity() const
        {
            if (m_State == nullptr)
            {
                return {};
            }

            return m_State->velocity;
        }

        bool IsOnGround() const
        {
            return m_State != nullptr && m_State->onGround;
        }

        const Actor& At(float x, float y) const
        {
            if (const auto node = Node())
            {
                node->SetPosition(x, y);
            }

            return *this;
        }

        const Actor& At(const Vec2& position) const
        {
            if (const auto node = Node())
            {
                node->SetPosition(position);
            }

            return *this;
        }

        const Actor& Move(float x, float y) const
        {
            return Move({ x, y });
        }

        const Actor& Move(const Vec2& delta) const
        {
            return ApplyMovement(delta);
        }

        const Actor& Size(float width, float height) const
        {
            if (const auto node = Node())
            {
                node->SetContentSize(width, height);
            }

            return *this;
        }

        const Actor& Size(const Vec2& size) const
        {
            if (const auto node = Node())
            {
                node->SetContentSize(size);
            }

            return *this;
        }

        const Actor& Scale(float uniformScale) const
        {
            if (const auto node = Node())
            {
                node->SetScale(uniformScale);
            }

            return *this;
        }

        const Actor& Scale(float x, float y) const
        {
            if (const auto node = Node())
            {
                node->SetScale({ x, y });
            }

            return *this;
        }

        const Actor& Scale(const Vec2& scale) const
        {
            if (const auto node = Node())
            {
                node->SetScale(scale);
            }

            return *this;
        }

        const Actor& Layer(int zOrder) const
        {
            if (const auto node = Node())
            {
                node->SetLocalZOrder(zOrder);
            }

            return *this;
        }

        const Actor& Show(bool visible = true) const
        {
            if (const auto node = Node())
            {
                node->SetVisible(visible);
            }

            return *this;
        }

        const Actor& Hide() const
        {
            return Show(false);
        }

        const Actor& Paint(Color color) const
        {
            if (const auto sprite = std::dynamic_pointer_cast<honto::Sprite>(Node()))
            {
                sprite->SetColor(color);
            }
            else if (const auto layer = std::dynamic_pointer_cast<honto::LayerColor>(Node()))
            {
                layer->SetColor(color);
            }
            else if (const auto frame = std::dynamic_pointer_cast<detail::FrameNode>(Node()))
            {
                frame->SetColor(color);
            }
            else if (const auto label = std::dynamic_pointer_cast<honto::Label>(Node()))
            {
                label->SetColor(color);
            }
            else if (const auto bar = std::dynamic_pointer_cast<honto::ProgressBar>(Node()))
            {
                bar->SetFillColor(color);
            }
            else if (const auto button = std::dynamic_pointer_cast<honto::Button>(Node()))
            {
                button->SetNormalColor(color);
            }

            return *this;
        }

        const Actor& Paint(std::uint8_t r, std::uint8_t g, std::uint8_t b, std::uint8_t a = 255) const
        {
            return Paint(RGBA(r, g, b, a));
        }

        const Actor& UseTexture(const std::shared_ptr<Texture>& texture) const
        {
            if (const auto sprite = std::dynamic_pointer_cast<honto::Sprite>(Node()))
            {
                sprite->SetTexture(texture);
            }

            return *this;
        }

        const Actor& UseTextureRegion(int x, int y, int width, int height) const
        {
            if (const auto sprite = std::dynamic_pointer_cast<honto::Sprite>(Node()))
            {
                sprite->SetTextureRegion({ x, y, width, height });
            }

            return *this;
        }

        const Actor& ClearTextureRegion() const
        {
            if (const auto sprite = std::dynamic_pointer_cast<honto::Sprite>(Node()))
            {
                sprite->ClearTextureRegion();
            }

            return *this;
        }

        const Actor& UseTextureFrame(int frameIndex, int frameWidth, int frameHeight, int columns = 0) const
        {
            if (const auto sprite = std::dynamic_pointer_cast<honto::Sprite>(Node()))
            {
                sprite->SetTextureFrame(frameIndex, frameWidth, frameHeight, columns);
            }

            return *this;
        }

        const Actor& Thickness(int thickness) const
        {
            if (const auto frame = std::dynamic_pointer_cast<detail::FrameNode>(Node()))
            {
                frame->SetThickness(thickness);
            }

            return *this;
        }

        const Actor& TextValue(const std::string& text) const
        {
            if (const auto label = std::dynamic_pointer_cast<honto::Label>(Node()))
            {
                label->SetText(text);
            }
            else if (const auto button = std::dynamic_pointer_cast<honto::Button>(Node()))
            {
                button->SetText(text);
            }

            return *this;
        }

        const Actor& TextScale(int glyphScale) const
        {
            if (const auto label = std::dynamic_pointer_cast<honto::Label>(Node()))
            {
                label->SetGlyphScale(glyphScale);
            }
            else if (const auto button = std::dynamic_pointer_cast<honto::Button>(Node()))
            {
                button->SetGlyphScale(glyphScale);
            }

            return *this;
        }

        const Actor& UseCamera(bool useCamera) const
        {
            if (const auto label = std::dynamic_pointer_cast<honto::Label>(Node()))
            {
                label->SetUseCamera(useCamera);
            }
            else if (const auto bar = std::dynamic_pointer_cast<honto::ProgressBar>(Node()))
            {
                bar->SetUseCamera(useCamera);
            }
            else if (const auto button = std::dynamic_pointer_cast<honto::Button>(Node()))
            {
                button->SetUseCamera(useCamera);
            }

            return *this;
        }

        const Actor& BarValue(float value) const
        {
            if (const auto bar = std::dynamic_pointer_cast<honto::ProgressBar>(Node()))
            {
                bar->SetValue(value);
            }

            return *this;
        }

        const Actor& BarColors(Color fill, Color background, Color border) const
        {
            if (const auto bar = std::dynamic_pointer_cast<honto::ProgressBar>(Node()))
            {
                bar->SetFillColor(fill);
                bar->SetBackgroundColor(background);
                bar->SetBorderColor(border);
            }

            return *this;
        }

        const Actor& ButtonColors(Color normal, Color hover, Color pressed, Color border) const
        {
            if (const auto button = std::dynamic_pointer_cast<honto::Button>(Node()))
            {
                button->SetNormalColor(normal);
                button->SetHoverColor(hover);
                button->SetPressedColor(pressed);
                button->SetBorderColor(border);
            }

            return *this;
        }

        const Actor& ButtonTextColor(Color color) const
        {
            if (const auto button = std::dynamic_pointer_cast<honto::Button>(Node()))
            {
                button->SetTextColor(color);
            }

            return *this;
        }

        const Actor& ButtonState(bool hovered, bool pressed) const
        {
            if (const auto button = std::dynamic_pointer_cast<honto::Button>(Node()))
            {
                button->SetHovered(hovered);
                button->SetPressed(pressed);
            }

            return *this;
        }

        const Actor& Velocity(float x, float y) const
        {
            return Velocity(Vec2 { x, y });
        }

        const Actor& Velocity(const Vec2& velocity) const
        {
            if (m_State != nullptr)
            {
                m_State->velocity = velocity;
            }

            return *this;
        }

        const Actor& MoveByVelocity() const
        {
            if (m_State != nullptr)
            {
                m_State->movesByVelocity = true;
            }

            return EnsurePhysics();
        }

        const Actor& UseGravity(float scale = 1.0f) const
        {
            if (m_State != nullptr)
            {
                m_State->usesGravity = true;
                m_State->gravityScale = scale;
            }

            return EnsurePhysics();
        }

        const Actor& GroundAt(float y, float bounce = 0.0f) const
        {
            if (m_State != nullptr)
            {
                m_State->hasGround = true;
                m_State->groundY = y;
                m_State->groundBounce = std::clamp(bounce, 0.0f, 1.0f);
            }

            return EnsurePhysics();
        }

        const Actor& Jump(float power) const
        {
            if (m_State != nullptr)
            {
                m_State->velocity.y = -std::abs(power);
                m_State->onGround = false;
            }

            return *this;
        }

        const Actor& MoveWithArrows(float speed, bool alsoUseWASD = true) const
        {
            return OnUpdate(
                [speed, alsoUseWASD](Actor& self, float deltaTime)
                {
                    Vec2 move {};

                    if (Pressing(Key::Left) || (alsoUseWASD && Pressing(Key::A)))
                    {
                        move.x -= 1.0f;
                    }

                    if (Pressing(Key::Right) || (alsoUseWASD && Pressing(Key::D)))
                    {
                        move.x += 1.0f;
                    }

                    if (Pressing(Key::Up) || (alsoUseWASD && Pressing(Key::W)))
                    {
                        move.y -= 1.0f;
                    }

                    if (Pressing(Key::Down) || (alsoUseWASD && Pressing(Key::S)))
                    {
                        move.y += 1.0f;
                    }

                    self.Move(move * (speed * deltaTime));
                }
            );
        }

        const Actor& MoveLeftRight(float speed, bool alsoUseAD = true) const
        {
            return OnUpdate(
                [speed, alsoUseAD](Actor& self, float deltaTime)
                {
                    float direction = 0.0f;

                    if (Pressing(Key::Left) || (alsoUseAD && Pressing(Key::A)))
                    {
                        direction -= 1.0f;
                    }

                    if (Pressing(Key::Right) || (alsoUseAD && Pressing(Key::D)))
                    {
                        direction += 1.0f;
                    }

                    self.Move(direction * speed * deltaTime, 0.0f);
                }
            );
        }

        const Actor& JumpWhenPressed(Key key, float power) const
        {
            return OnUpdate(
                [key, power](Actor& self, float)
                {
                    if (Pressed(key) && self.IsOnGround())
                    {
                        self.Jump(power);
                    }
                }
            );
        }

        const Actor& KeepInside(float left, float top, float right, float bottom) const
        {
            return OnUpdate(
                [left, top, right, bottom](Actor& self, float)
                {
                    Vec2 position = self.Position();
                    position.x = std::clamp(position.x, left, right);
                    position.y = std::clamp(position.y, top, bottom);
                    self.At(position);
                }
            );
        }

        const Actor& BounceInside(float left, float top, float right, float bottom) const
        {
            return OnUpdate(
                [left, top, right, bottom](Actor& self, float)
                {
                    Vec2 position = self.Position();
                    Vec2 velocity = self.Velocity();

                    if (position.x <= left || position.x >= right)
                    {
                        velocity.x *= -1.0f;
                        position.x = std::clamp(position.x, left, right);
                    }

                    if (position.y <= top || position.y >= bottom)
                    {
                        velocity.y *= -1.0f;
                        position.y = std::clamp(position.y, top, bottom);
                    }

                    self.At(position);
                    self.Velocity(velocity);
                }
            );
        }

        const Actor& PatrolX(float left, float right, float speed) const
        {
            auto direction = std::make_shared<float>(1.0f);
            return OnUpdate(
                [left, right, speed, direction](Actor& self, float deltaTime)
                {
                    if (self.Position().x <= left)
                    {
                        *direction = 1.0f;
                    }
                    else if (self.Position().x >= right)
                    {
                        *direction = -1.0f;
                    }

                    self.Move(*direction * speed * deltaTime, 0.0f);
                }
            );
        }

        const Actor& Chase(const Actor& target, float speed, float stopDistance = 0.0f) const
        {
            return OnUpdate(
                [target, speed, stopDistance](Actor& self, float deltaTime)
                {
                    if (!target)
                    {
                        return;
                    }

                    Vec2 delta = target.Position() - self.Position();
                    const float length = std::sqrt((delta.x * delta.x) + (delta.y * delta.y));
                    if (length <= std::max(0.0f, stopDistance) || length <= 0.001f)
                    {
                        return;
                    }

                    delta = delta / length;
                    self.Move(delta * (speed * deltaTime));
                }
            );
        }

        const Actor& ChaseX(const Actor& target, float speed, float stopDistance = 0.0f) const
        {
            return OnUpdate(
                [target, speed, stopDistance](Actor& self, float deltaTime)
                {
                    if (!target)
                    {
                        return;
                    }

                    const float delta = target.Position().x - self.Position().x;
                    if (std::abs(delta) <= std::max(0.0f, stopDistance))
                    {
                        return;
                    }

                    const float direction = delta < 0.0f ? -1.0f : 1.0f;
                    self.Move(direction * speed * deltaTime, 0.0f);
                }
            );
        }

        const Actor& OnUpdate(std::function<void(Actor&, float)> fn) const
        {
            if (fn == nullptr)
            {
                return *this;
            }

            if (const auto stage = LockStage())
            {
                if (stage->scene != nullptr)
                {
                    stage->scene->EveryFrame();
                }

                stage->updates.push_back(
                    [state = m_State, fn = std::move(fn)](float deltaTime)
                    {
                        if (state == nullptr || state->node == nullptr)
                        {
                            return;
                        }

                        Actor actor(state);
                        fn(actor, deltaTime);
                    }
                );
            }

            return *this;
        }

        bool Touching(const Actor& other) const
        {
            if (!(*this) || !other)
            {
                return false;
            }

            const Vec2 myPosition = Position();
            const Vec2 mySize = Size();
            const Vec2 otherPosition = other.Position();
            const Vec2 otherSize = other.Size();

            return myPosition.x < otherPosition.x + otherSize.x &&
                   myPosition.x + mySize.x > otherPosition.x &&
                   myPosition.y < otherPosition.y + otherSize.y &&
                   myPosition.y + mySize.y > otherPosition.y;
        }

        bool ContainsPoint(const Vec2& point) const
        {
            if (!(*this))
            {
                return false;
            }

            const auto node = Node();
            if (node == nullptr || !node->IsVisible())
            {
                return false;
            }

            const Vec2 min = Position();
            const Vec2 max = min + (Size() * ScaleValue());
            return point.x >= min.x &&
                   point.x <= max.x &&
                   point.y >= min.y &&
                   point.y <= max.y;
        }

        bool TouchingMap(const TileMapActor& map) const;

        const Actor& CollideWithMap(const TileMapActor& map) const;

        std::shared_ptr<honto::Node> Share() const
        {
            return Node();
        }

        Animation Animate() const;
        FrameAnimation AnimateFrames() const;

        const Actor& Code(const std::string& command) const
        {
            const detail::ParsedCommand parsed = detail::ParseCommand(command);
            if (!parsed.valid)
            {
                return *this;
            }

            const std::string name = detail::NormalizeCommandName(parsed.name);
            const auto& args = parsed.args;

            float x = 0.0f;
            float y = 0.0f;
            float z = 0.0f;
            float w = 0.0f;
            bool enabled = false;
            bool secondEnabled = false;
            int integer = 0;
            std::size_t consumed = 0;
            Color color {};

            if (name == "at" && args.size() >= 2 &&
                detail::TryParseFloat(args[0], x) &&
                detail::TryParseFloat(args[1], y))
            {
                return At(x, y);
            }

            if (name == "move" && args.size() >= 2 &&
                detail::TryParseFloat(args[0], x) &&
                detail::TryParseFloat(args[1], y))
            {
                return Move(x, y);
            }

            if (name == "size" && args.size() >= 2 &&
                detail::TryParseFloat(args[0], x) &&
                detail::TryParseFloat(args[1], y))
            {
                return Size(x, y);
            }

            if (name == "scale")
            {
                if (args.size() == 1 && detail::TryParseFloat(args[0], x))
                {
                    return Scale(x);
                }

                if (args.size() >= 2 &&
                    detail::TryParseFloat(args[0], x) &&
                    detail::TryParseFloat(args[1], y))
                {
                    return Scale(x, y);
                }
            }

            if (name == "layer" && !args.empty() && detail::TryParseInt(args[0], integer))
            {
                return Layer(integer);
            }

            if (name == "show")
            {
                if (args.empty())
                {
                    return Show(true);
                }

                if (detail::TryParseBool(args[0], enabled))
                {
                    return Show(enabled);
                }
            }

            if (name == "hide")
            {
                return Hide();
            }

            if ((name == "paint" || name == "color" || name == "tint") &&
                detail::TryParseColor(args, 0, 1, color, consumed) &&
                consumed == args.size())
            {
                return Paint(color);
            }

            if ((name == "text" || name == "textvalue") && !args.empty())
            {
                return TextValue(detail::Unquote(args[0]));
            }

            if (name == "textscale" && !args.empty() && detail::TryParseInt(args[0], integer))
            {
                return TextScale(integer);
            }

            if (name == "usecamera" && !args.empty() && detail::TryParseBool(args[0], enabled))
            {
                return UseCamera(enabled);
            }

            if (name == "barvalue" && !args.empty() && detail::TryParseFloat(args[0], x))
            {
                return BarValue(x);
            }

            if (name == "barcolors")
            {
                std::vector<Color> colors;
                if (detail::TryParseColors(args, 3, colors))
                {
                    return BarColors(colors[0], colors[1], colors[2]);
                }
            }

            if (name == "buttoncolors")
            {
                std::vector<Color> colors;
                if (detail::TryParseColors(args, 4, colors))
                {
                    return ButtonColors(colors[0], colors[1], colors[2], colors[3]);
                }
            }

            if (name == "buttontextcolor" &&
                detail::TryParseColor(args, 0, 1, color, consumed) &&
                consumed == args.size())
            {
                return ButtonTextColor(color);
            }

            if (name == "buttonstate" &&
                args.size() >= 2 &&
                detail::TryParseBool(args[0], enabled) &&
                detail::TryParseBool(args[1], secondEnabled))
            {
                return ButtonState(enabled, secondEnabled);
            }

            if (name == "usetexture" && !args.empty())
            {
                return UseTexture(LoadTexture(detail::Unquote(args[0])));
            }

            if (name == "usetextureregion" &&
                args.size() >= 4 &&
                detail::TryParseInt(args[0], integer))
            {
                int regionY = 0;
                int regionWidth = 0;
                int regionHeight = 0;
                if (detail::TryParseInt(args[1], regionY) &&
                    detail::TryParseInt(args[2], regionWidth) &&
                    detail::TryParseInt(args[3], regionHeight))
                {
                    return UseTextureRegion(integer, regionY, regionWidth, regionHeight);
                }
            }

            if (name == "cleartextureregion")
            {
                return ClearTextureRegion();
            }

            if (name == "usetextureframe")
            {
                int frameIndex = 0;
                int frameWidth = 0;
                int frameHeight = 0;
                int columns = 0;
                if (args.size() >= 3 &&
                    detail::TryParseInt(args[0], frameIndex) &&
                    detail::TryParseInt(args[1], frameWidth) &&
                    detail::TryParseInt(args[2], frameHeight))
                {
                    if (args.size() >= 4)
                    {
                        if (!detail::TryParseInt(args[3], columns))
                        {
                            columns = 0;
                        }
                    }

                    return UseTextureFrame(frameIndex, frameWidth, frameHeight, columns);
                }
            }

            if (name == "thickness" && !args.empty() && detail::TryParseInt(args[0], integer))
            {
                return Thickness(integer);
            }

            if (name == "velocity" && args.size() >= 2 &&
                detail::TryParseFloat(args[0], x) &&
                detail::TryParseFloat(args[1], y))
            {
                return Velocity(x, y);
            }

            if (name == "movebyvelocity")
            {
                return MoveByVelocity();
            }

            if (name == "usegravity")
            {
                if (args.empty())
                {
                    return UseGravity();
                }

                if (detail::TryParseFloat(args[0], x))
                {
                    return UseGravity(x);
                }
            }

            if (name == "groundat" && !args.empty() && detail::TryParseFloat(args[0], y))
            {
                if (args.size() >= 2 && detail::TryParseFloat(args[1], x))
                {
                    return GroundAt(y, x);
                }

                return GroundAt(y);
            }

            if (name == "jump" && !args.empty() && detail::TryParseFloat(args[0], x))
            {
                return Jump(x);
            }

            if (name == "movewitharrows" && !args.empty() && detail::TryParseFloat(args[0], x))
            {
                if (args.size() >= 2 && detail::TryParseBool(args[1], enabled))
                {
                    return MoveWithArrows(x, enabled);
                }

                return MoveWithArrows(x);
            }

            if (name == "moveleftright" && !args.empty() && detail::TryParseFloat(args[0], x))
            {
                if (args.size() >= 2 && detail::TryParseBool(args[1], enabled))
                {
                    return MoveLeftRight(x, enabled);
                }

                return MoveLeftRight(x);
            }

            if (name == "jumpwhenpressed" && args.size() >= 2)
            {
                Key key {};
                if (detail::TryParseKey(args[0], key) && detail::TryParseFloat(args[1], x))
                {
                    return JumpWhenPressed(key, x);
                }
            }

            if (name == "keepinside" && args.size() >= 4 &&
                detail::TryParseFloat(args[0], x) &&
                detail::TryParseFloat(args[1], y) &&
                detail::TryParseFloat(args[2], z) &&
                detail::TryParseFloat(args[3], w))
            {
                return KeepInside(x, y, z, w);
            }

            if (name == "bounceinside" && args.size() >= 4 &&
                detail::TryParseFloat(args[0], x) &&
                detail::TryParseFloat(args[1], y) &&
                detail::TryParseFloat(args[2], z) &&
                detail::TryParseFloat(args[3], w))
            {
                return BounceInside(x, y, z, w);
            }

            if (name == "patrolx" && args.size() >= 3 &&
                detail::TryParseFloat(args[0], x) &&
                detail::TryParseFloat(args[1], y) &&
                detail::TryParseFloat(args[2], z))
            {
                return PatrolX(x, y, z);
            }

            if (name == "collidewithmap" && !args.empty())
            {
                if (const auto stage = LockStage())
                {
                    const std::string targetName = detail::Unquote(args[0]);
                    const auto found = stage->namedActors.find(targetName);
                    if (found != stage->namedActors.end() &&
                        found->second != nullptr &&
                        std::dynamic_pointer_cast<honto::TileMap>(found->second->node) != nullptr)
                    {
                        if (m_State != nullptr)
                        {
                            m_State->collisionMap = std::dynamic_pointer_cast<honto::TileMap>(found->second->node);
                        }

                        return EnsurePhysics();
                    }
                }
            }

            if ((name == "chase" || name == "chasex") && args.size() >= 2)
            {
                if (const auto stage = LockStage())
                {
                    const std::string targetName = detail::Unquote(args[0]);
                    const auto found = stage->namedActors.find(targetName);
                    if (found != stage->namedActors.end() &&
                        found->second != nullptr &&
                        detail::TryParseFloat(args[1], x))
                    {
                        Actor target(found->second);
                        float stopDistance = 0.0f;
                        if (args.size() >= 3)
                        {
                            detail::TryParseFloat(args[2], stopDistance);
                        }

                        return name == "chase"
                            ? Chase(target, x, stopDistance)
                            : ChaseX(target, x, stopDistance);
                    }
                }
            }

            return *this;
        }

        const Actor& hontoCode(const std::string& command) const
        {
            return Code(command);
        }

        const Actor& hontoAt(float x, float y) const
        {
            return At(x, y);
        }

        const Actor& hontoAt(const Vec2& position) const
        {
            return At(position);
        }

        const Actor& hontoMove(float x, float y) const
        {
            return Move(x, y);
        }

        const Actor& hontoMove(const Vec2& delta) const
        {
            return Move(delta);
        }

        const Actor& hontoSize(float width, float height) const
        {
            return Size(width, height);
        }

        const Actor& hontoSize(const Vec2& size) const
        {
            return Size(size);
        }

        const Actor& hontoScale(float uniformScale) const
        {
            return Scale(uniformScale);
        }

        const Actor& hontoScale(float x, float y) const
        {
            return Scale(x, y);
        }

        const Actor& hontoScale(const Vec2& scale) const
        {
            return Scale(scale);
        }

        const Actor& hontoLayer(int zOrder) const
        {
            return Layer(zOrder);
        }

        const Actor& hontoShow(bool visible = true) const
        {
            return Show(visible);
        }

        const Actor& hontoHide() const
        {
            return Hide();
        }

        const Actor& hontoPaint(Color color) const
        {
            return Paint(color);
        }

        const Actor& hontoPaint(std::uint8_t r, std::uint8_t g, std::uint8_t b, std::uint8_t a = 255) const
        {
            return Paint(r, g, b, a);
        }

        const Actor& hontoUseTexture(const std::shared_ptr<Texture>& texture) const
        {
            return UseTexture(texture);
        }

        const Actor& hontoTextValue(const std::string& text) const
        {
            return TextValue(text);
        }

        const Actor& hontoTextScale(int glyphScale) const
        {
            return TextScale(glyphScale);
        }

        const Actor& hontoUseCamera(bool useCamera) const
        {
            return UseCamera(useCamera);
        }

        const Actor& hontoBarValue(float value) const
        {
            return BarValue(value);
        }

        const Actor& hontoBarColors(Color fill, Color background, Color border) const
        {
            return BarColors(fill, background, border);
        }

        const Actor& hontoButtonColors(Color normal, Color hover, Color pressed, Color border) const
        {
            return ButtonColors(normal, hover, pressed, border);
        }

        const Actor& hontoButtonTextColor(Color color) const
        {
            return ButtonTextColor(color);
        }

        const Actor& hontoButtonState(bool hovered, bool pressed) const
        {
            return ButtonState(hovered, pressed);
        }

        const Actor& hontoUseTextureRegion(int x, int y, int width, int height) const
        {
            return UseTextureRegion(x, y, width, height);
        }

        const Actor& hontoClearTextureRegion() const
        {
            return ClearTextureRegion();
        }

        const Actor& hontoUseTextureFrame(int frameIndex, int frameWidth, int frameHeight, int columns = 0) const
        {
            return UseTextureFrame(frameIndex, frameWidth, frameHeight, columns);
        }

        const Actor& hontoThickness(int thickness) const
        {
            return Thickness(thickness);
        }

        const Actor& hontoVelocity(float x, float y) const
        {
            return Velocity(x, y);
        }

        const Actor& hontoVelocity(const Vec2& velocity) const
        {
            return Velocity(velocity);
        }

        const Actor& hontoMoveByVelocity() const
        {
            return MoveByVelocity();
        }

        const Actor& hontoUseGravity(float scale = 1.0f) const
        {
            return UseGravity(scale);
        }

        const Actor& hontoGroundAt(float y, float bounce = 0.0f) const
        {
            return GroundAt(y, bounce);
        }

        const Actor& hontoJump(float power) const
        {
            return Jump(power);
        }

        const Actor& hontoMoveWithArrows(float speed, bool alsoUseWASD = true) const
        {
            return MoveWithArrows(speed, alsoUseWASD);
        }

        const Actor& hontoMoveLeftRight(float speed, bool alsoUseAD = true) const
        {
            return MoveLeftRight(speed, alsoUseAD);
        }

        const Actor& hontoJumpWhenPressed(Key key, float power) const
        {
            return JumpWhenPressed(key, power);
        }

        const Actor& hontoKeepInside(float left, float top, float right, float bottom) const
        {
            return KeepInside(left, top, right, bottom);
        }

        const Actor& hontoBounceInside(float left, float top, float right, float bottom) const
        {
            return BounceInside(left, top, right, bottom);
        }

        const Actor& hontoPatrolX(float left, float right, float speed) const
        {
            return PatrolX(left, right, speed);
        }

        const Actor& hontoChase(const Actor& target, float speed, float stopDistance = 0.0f) const
        {
            return Chase(target, speed, stopDistance);
        }

        const Actor& hontoChaseX(const Actor& target, float speed, float stopDistance = 0.0f) const
        {
            return ChaseX(target, speed, stopDistance);
        }

        const Actor& hontoOnUpdate(std::function<void(Actor&, float)> fn) const
        {
            return OnUpdate(std::move(fn));
        }

        bool hontoTouching(const Actor& other) const
        {
            return Touching(other);
        }

        bool hontoContainsPoint(const Vec2& point) const
        {
            return ContainsPoint(point);
        }

        bool hontoTouchingMap(const TileMapActor& map) const
        {
            return TouchingMap(map);
        }

        const Actor& hontoCollideWithMap(const TileMapActor& map) const
        {
            return CollideWithMap(map);
        }

        bool hontoIsOnGround() const
        {
            return IsOnGround();
        }

        Animation hontoAnimate() const;
        FrameAnimation hontoAnimateFrames() const;

    private:
        std::shared_ptr<honto::Node> Node() const
        {
            if (m_State == nullptr)
            {
                return nullptr;
            }

            return m_State->node;
        }

        std::shared_ptr<detail::StageState> LockStage() const
        {
            if (m_State == nullptr)
            {
                return nullptr;
            }

            return m_State->stage.lock();
        }

        std::shared_ptr<honto::TileMap> LockCollisionMap() const
        {
            if (m_State == nullptr)
            {
                return nullptr;
            }

            return m_State->collisionMap.lock();
        }

        const Actor& ApplyMovement(const Vec2& delta) const
        {
            if (const auto node = Node())
            {
                if (const auto tileMap = LockCollisionMap())
                {
                    Vec2 position = node->GetPosition();
                    Vec2 velocity = m_State != nullptr ? m_State->velocity : Vec2 {};
                    bool collidedX = false;
                    bool collidedY = false;
                    bool onGround = m_State != nullptr ? m_State->onGround : false;

                    tileMap->ResolveMovement(position, node->GetContentSize(), velocity, delta, collidedX, collidedY, onGround);
                    node->SetPosition(position);

                    if (m_State != nullptr)
                    {
                        m_State->velocity = velocity;
                        m_State->onGround = (delta.y == 0.0f) ? m_State->onGround || onGround : onGround;
                    }
                }
                else
                {
                    node->SetPosition(node->GetPosition() + delta);

                    if (m_State != nullptr && delta.y < 0.0f)
                    {
                        m_State->onGround = false;
                    }
                }
            }

            return *this;
        }

        const Actor& EnsurePhysics() const
        {
            if (m_State == nullptr || m_State->physicsAttached)
            {
                return *this;
            }

            m_State->physicsAttached = true;
            return OnUpdate(
                [](Actor& self, float deltaTime)
                {
                    if (self.m_State == nullptr)
                    {
                        return;
                    }

                    if (self.m_State->usesGravity)
                    {
                        if (const auto stage = self.LockStage())
                        {
                            self.m_State->velocity += stage->gravity * (self.m_State->gravityScale * deltaTime);
                        }
                    }

                    if (self.m_State->movesByVelocity || self.m_State->usesGravity)
                    {
                        self.ApplyMovement(self.m_State->velocity * deltaTime);
                    }

                    if (self.m_State->hasGround && self.LockCollisionMap() == nullptr)
                    {
                        Vec2 position = self.Position();
                        if (position.y >= self.m_State->groundY)
                        {
                            position.y = self.m_State->groundY;

                            if (self.m_State->velocity.y > 0.0f)
                            {
                                self.m_State->velocity.y = -self.m_State->velocity.y * self.m_State->groundBounce;
                                if (std::abs(self.m_State->velocity.y) < 8.0f || self.m_State->groundBounce <= 0.0f)
                                {
                                    self.m_State->velocity.y = 0.0f;
                                }
                            }

                            self.m_State->onGround = true;
                            self.At(position);
                        }
                        else
                        {
                            self.m_State->onGround = false;
                        }
                    }
                }
            );
        }

        std::shared_ptr<detail::ActorState> m_State;
    };

    class Animation
    {
    public:
        explicit Animation(Actor actor)
            : m_Actor(std::move(actor))
        {
        }

        Animation& MoveTo(float x, float y)
        {
            m_HasMove = true;
            m_TargetPosition = { x, y };
            return *this;
        }

        Animation& MoveTo(const Vec2& position)
        {
            m_HasMove = true;
            m_TargetPosition = position;
            return *this;
        }

        Animation& ScaleTo(float uniformScale)
        {
            return ScaleTo(uniformScale, uniformScale);
        }

        Animation& ScaleTo(float x, float y)
        {
            m_HasScale = true;
            m_TargetScale = { x, y };
            return *this;
        }

        Animation& ScaleTo(const Vec2& scale)
        {
            m_HasScale = true;
            m_TargetScale = scale;
            return *this;
        }

        Animation& PaintTo(Color color)
        {
            m_HasColor = true;
            m_TargetColor = color;
            return *this;
        }

        Animation& PaintTo(std::uint8_t r, std::uint8_t g, std::uint8_t b, std::uint8_t a = 255)
        {
            return PaintTo(RGBA(r, g, b, a));
        }

        Animation& In(float seconds)
        {
            m_Duration = std::max(0.01f, seconds);
            return *this;
        }

        Animation& Delay(float seconds)
        {
            m_Delay = std::max(0.0f, seconds);
            return *this;
        }

        Animation& Loop(bool enabled = true)
        {
            m_Loop = enabled;
            return *this;
        }

        Animation& PingPong(bool enabled = true)
        {
            m_PingPong = enabled;
            return *this;
        }

        Animation& hontoMoveTo(float x, float y)
        {
            return MoveTo(x, y);
        }

        Animation& hontoMoveTo(const Vec2& position)
        {
            return MoveTo(position);
        }

        Animation& hontoScaleTo(float uniformScale)
        {
            return ScaleTo(uniformScale);
        }

        Animation& hontoScaleTo(float x, float y)
        {
            return ScaleTo(x, y);
        }

        Animation& hontoScaleTo(const Vec2& scale)
        {
            return ScaleTo(scale);
        }

        Animation& hontoPaintTo(Color color)
        {
            return PaintTo(color);
        }

        Animation& hontoPaintTo(std::uint8_t r, std::uint8_t g, std::uint8_t b, std::uint8_t a = 255)
        {
            return PaintTo(r, g, b, a);
        }

        Animation& hontoIn(float seconds)
        {
            return In(seconds);
        }

        Animation& hontoDelay(float seconds)
        {
            return Delay(seconds);
        }

        Animation& hontoLoop(bool enabled = true)
        {
            return Loop(enabled);
        }

        Animation& hontoPingPong(bool enabled = true)
        {
            return PingPong(enabled);
        }

        const Actor& Play() const
        {
            if (!m_Actor || (!m_HasMove && !m_HasScale && !m_HasColor))
            {
                return m_Actor;
            }

            const Vec2 startPosition = m_Actor.Position();
            const Vec2 startScale = m_Actor.ScaleValue();
            const Color startColor = m_Actor.Tint();
            const float duration = std::max(0.01f, m_Duration);
            const float delay = std::max(0.0f, m_Delay);
            const bool loops = m_Loop;
            const bool pingPong = m_PingPong;

            return m_Actor.OnUpdate(
                [
                    startPosition,
                    targetPosition = m_TargetPosition,
                    startScale,
                    targetScale = m_TargetScale,
                    startColor,
                    targetColor = m_TargetColor,
                    hasMove = m_HasMove,
                    hasScale = m_HasScale,
                    hasColor = m_HasColor,
                    duration,
                    delay,
                    loops,
                    pingPong,
                    elapsed = 0.0f,
                    finished = false
                ](Actor& self, float deltaTime) mutable
                {
                    if (finished && !loops)
                    {
                        return;
                    }

                    elapsed += deltaTime;
                    if (elapsed < delay)
                    {
                        return;
                    }

                    const float cycleDuration = pingPong ? (duration * 2.0f) : duration;
                    float localTime = elapsed - delay;

                    if (loops)
                    {
                        localTime = std::fmod(localTime, cycleDuration);
                        if (localTime < 0.0f)
                        {
                            localTime += cycleDuration;
                        }
                    }
                    else if (localTime >= cycleDuration)
                    {
                        localTime = cycleDuration;
                        finished = true;
                    }

                    float t = localTime / duration;
                    if (pingPong && localTime > duration)
                    {
                        t = 1.0f - ((localTime - duration) / duration);
                    }

                    t = std::clamp(t, 0.0f, 1.0f);

                    if (hasMove)
                    {
                        self.At(detail::Lerp(startPosition, targetPosition, t));
                    }

                    if (hasScale)
                    {
                        self.Scale(detail::Lerp(startScale, targetScale, t));
                    }

                    if (hasColor)
                    {
                        self.Paint(detail::Lerp(startColor, targetColor, t));
                    }
                }
            );
        }

        const Actor& hontoPlay() const
        {
            return Play();
        }

    private:
        Actor m_Actor;
        float m_Duration = 0.35f;
        float m_Delay = 0.0f;
        bool m_Loop = false;
        bool m_PingPong = false;
        bool m_HasMove = false;
        bool m_HasScale = false;
        bool m_HasColor = false;
        Vec2 m_TargetPosition {};
        Vec2 m_TargetScale { 1.0f, 1.0f };
        Color m_TargetColor { 255, 255, 255, 255 };
    };

    inline Animation Actor::Animate() const
    {
        return Animation(*this);
    }

    inline Animation Actor::hontoAnimate() const
    {
        return Animate();
    }

    class FrameAnimation
    {
    public:
        explicit FrameAnimation(Actor actor)
            : m_Actor(std::move(actor))
        {
        }

        FrameAnimation& Texture(const std::shared_ptr<honto::Texture>& texture)
        {
            m_Texture = texture;
            return *this;
        }

        FrameAnimation& Texture(const std::string& path)
        {
            return Texture(LoadTexture(path));
        }

        FrameAnimation& FrameSize(int width, int height)
        {
            m_FrameWidth = std::max(1, width);
            m_FrameHeight = std::max(1, height);
            return *this;
        }

        FrameAnimation& Frames(const std::vector<int>& frames)
        {
            m_Frames = frames;
            return *this;
        }

        FrameAnimation& Frames(std::initializer_list<int> frames)
        {
            m_Frames.assign(frames.begin(), frames.end());
            return *this;
        }

        FrameAnimation& Range(int startFrame, int count)
        {
            m_Frames.clear();

            for (int index = 0; index < count; ++index)
            {
                m_Frames.push_back(startFrame + index);
            }

            return *this;
        }

        FrameAnimation& Columns(int columns)
        {
            m_Columns = std::max(0, columns);
            return *this;
        }

        FrameAnimation& FPS(float framesPerSecond)
        {
            m_Fps = std::max(1.0f, framesPerSecond);
            return *this;
        }

        FrameAnimation& Loop(bool enabled = true)
        {
            m_Loop = enabled;
            return *this;
        }

        FrameAnimation& PingPong(bool enabled = true)
        {
            m_PingPong = enabled;
            return *this;
        }

        FrameAnimation& hontoTexture(const std::shared_ptr<honto::Texture>& texture)
        {
            return Texture(texture);
        }

        FrameAnimation& hontoTexture(const std::string& path)
        {
            return Texture(path);
        }

        FrameAnimation& hontoFrameSize(int width, int height)
        {
            return FrameSize(width, height);
        }

        FrameAnimation& hontoFrames(const std::vector<int>& frames)
        {
            return Frames(frames);
        }

        FrameAnimation& hontoFrames(std::initializer_list<int> frames)
        {
            return Frames(frames);
        }

        FrameAnimation& hontoRange(int startFrame, int count)
        {
            return Range(startFrame, count);
        }

        FrameAnimation& hontoColumns(int columns)
        {
            return Columns(columns);
        }

        FrameAnimation& hontoFPS(float framesPerSecond)
        {
            return FPS(framesPerSecond);
        }

        FrameAnimation& hontoLoop(bool enabled = true)
        {
            return Loop(enabled);
        }

        FrameAnimation& hontoPingPong(bool enabled = true)
        {
            return PingPong(enabled);
        }

        const Actor& Play() const
        {
            if (!m_Actor || m_FrameWidth <= 0 || m_FrameHeight <= 0)
            {
                return m_Actor;
            }

            if (m_Texture != nullptr)
            {
                m_Actor.UseTexture(m_Texture);
            }

            const std::vector<int> sequence = m_Frames;
            if (sequence.empty())
            {
                return m_Actor;
            }

            m_Actor.UseTextureFrame(sequence.front(), m_FrameWidth, m_FrameHeight, m_Columns);

            return m_Actor.OnUpdate(
                [
                    sequence,
                    frameWidth = m_FrameWidth,
                    frameHeight = m_FrameHeight,
                    columns = m_Columns,
                    fps = m_Fps,
                    loops = m_Loop,
                    pingPong = m_PingPong,
                    elapsed = 0.0f,
                    currentIndex = -1,
                    finished = false
                ](Actor& self, float deltaTime) mutable
                {
                    if (finished && !loops)
                    {
                        return;
                    }

                    elapsed += deltaTime;
                    const int sequenceCount = static_cast<int>(sequence.size());
                    const int cycleCount = pingPong && sequenceCount > 1 ? ((sequenceCount * 2) - 2) : sequenceCount;

                    if (cycleCount <= 0)
                    {
                        return;
                    }

                    int cycleIndex = static_cast<int>(std::floor(elapsed * fps));
                    if (loops)
                    {
                        cycleIndex %= cycleCount;
                        if (cycleIndex < 0)
                        {
                            cycleIndex += cycleCount;
                        }
                    }
                    else if (cycleIndex >= cycleCount)
                    {
                        cycleIndex = cycleCount - 1;
                        finished = true;
                    }

                    int sequenceIndex = cycleIndex;
                    if (pingPong && sequenceCount > 1 && cycleIndex >= sequenceCount)
                    {
                        sequenceIndex = (sequenceCount - 2) - (cycleIndex - sequenceCount);
                    }

                    sequenceIndex = std::clamp(sequenceIndex, 0, sequenceCount - 1);
                    if (sequenceIndex == currentIndex)
                    {
                        return;
                    }

                    currentIndex = sequenceIndex;
                    self.UseTextureFrame(sequence[static_cast<std::size_t>(sequenceIndex)], frameWidth, frameHeight, columns);
                }
            );
        }

        const Actor& hontoPlay() const
        {
            return Play();
        }

    private:
        Actor m_Actor;
        std::shared_ptr<honto::Texture> m_Texture;
        std::vector<int> m_Frames;
        int m_FrameWidth = 16;
        int m_FrameHeight = 16;
        int m_Columns = 0;
        float m_Fps = 8.0f;
        bool m_Loop = true;
        bool m_PingPong = false;
    };

    inline FrameAnimation Actor::AnimateFrames() const
    {
        return FrameAnimation(*this);
    }

    inline FrameAnimation Actor::hontoAnimateFrames() const
    {
        return AnimateFrames();
    }

    class TileMapActor : public Actor
    {
    public:
        TileMapActor() = default;
        explicit TileMapActor(const Actor& actor)
            : Actor(actor)
        {
        }

        TileMapActor& Map(const std::vector<std::string>& map) const
        {
            if (const auto tileMap = View())
            {
                tileMap->SetMap(map);
            }

            return const_cast<TileMapActor&>(*this);
        }

        TileMapActor& TileSize(float width, float height) const
        {
            if (const auto tileMap = View())
            {
                tileMap->SetTileSize(width, height);
            }

            return const_cast<TileMapActor&>(*this);
        }

        TileMapActor& Tile(char tile, Color color, bool solid = false, bool visible = true) const
        {
            if (const auto tileMap = View())
            {
                tileMap->SetTile(tile, color, solid, visible);
            }

            return const_cast<TileMapActor&>(*this);
        }

        TileMapActor& TileTexture(char tile, const std::shared_ptr<Texture>& texture, Color tint = RGBA(255, 255, 255), bool solid = false, bool visible = true) const
        {
            if (const auto tileMap = View())
            {
                tileMap->SetTileTexture(tile, texture, tint, solid, visible);
            }

            return const_cast<TileMapActor&>(*this);
        }

        TileMapActor& TileTextureRegion(
            char tile,
            const std::shared_ptr<Texture>& texture,
            int x,
            int y,
            int width,
            int height,
            Color tint = RGBA(255, 255, 255),
            bool solid = false,
            bool visible = true
        ) const
        {
            if (const auto tileMap = View())
            {
                tileMap->SetTileTextureRegion(tile, texture, { x, y, width, height }, tint, solid, visible);
            }

            return const_cast<TileMapActor&>(*this);
        }

        TileMapActor& TileSolid(char tile, bool solid) const
        {
            if (const auto tileMap = View())
            {
                tileMap->SetTileSolid(tile, solid);
            }

            return const_cast<TileMapActor&>(*this);
        }

        TileMapActor& TileVisible(char tile, bool visible) const
        {
            if (const auto tileMap = View())
            {
                tileMap->SetTileVisible(tile, visible);
            }

            return const_cast<TileMapActor&>(*this);
        }

        char Cell(int column, int row) const
        {
            if (const auto tileMap = View())
            {
                return tileMap->GetCell(column, row);
            }

            return '\0';
        }

        TileMapActor& Cell(int column, int row, char tile) const
        {
            if (const auto tileMap = View())
            {
                tileMap->SetCell(column, row, tile);
            }

            return const_cast<TileMapActor&>(*this);
        }

        bool WorldToCell(const Vec2& point, int& column, int& row) const
        {
            if (const auto tileMap = View())
            {
                return tileMap->WorldToCell(point, column, row);
            }

            column = 0;
            row = 0;
            return false;
        }

        bool Collides(const Actor& actor) const
        {
            if (const auto tileMap = View())
            {
                return tileMap->CollidesRect(actor.Position(), actor.Size());
            }

            return false;
        }

        bool IsSolidAt(const Vec2& point) const
        {
            if (const auto tileMap = View())
            {
                return tileMap->IsSolidAtWorldPoint(point);
            }

            return false;
        }

        TileMapActor& Code(const std::string& command) const
        {
            const detail::ParsedCommand parsed = detail::ParseCommand(command);
            if (!parsed.valid)
            {
                Actor::Code(command);
                return const_cast<TileMapActor&>(*this);
            }

            const std::string name = detail::NormalizeCommandName(parsed.name);
            const auto& args = parsed.args;

            char tile = '\0';
            int column = 0;
            int row = 0;
            float x = 0.0f;
            float y = 0.0f;
            std::size_t consumed = 0;
            bool enabled = false;
            Color color {};

            if (name == "map" && !args.empty())
            {
                return Map(detail::ParseMapRows(args[0]));
            }

            if (name == "tilesize" &&
                args.size() >= 2 &&
                detail::TryParseFloat(args[0], x) &&
                detail::TryParseFloat(args[1], y))
            {
                return TileSize(x, y);
            }

            if (name == "tile" &&
                args.size() >= 4 &&
                detail::TryParseChar(args[0], tile) &&
                detail::TryParseLooseColor(args, 1, color, consumed))
            {
                bool solid = false;
                bool visible = true;
                std::size_t next = 1 + consumed;
                if (next < args.size())
                {
                    detail::TryParseBool(args[next], solid);
                    ++next;
                }

                if (next < args.size())
                {
                    detail::TryParseBool(args[next], visible);
                }

                return Tile(tile, color, solid, visible);
            }

            if (name == "tiletexture" &&
                args.size() >= 2 &&
                detail::TryParseChar(args[0], tile))
            {
                return TileTexture(tile, LoadTexture(detail::Unquote(args[1])));
            }

            if (name == "tiletextureregion" &&
                args.size() >= 6 &&
                detail::TryParseChar(args[0], tile) &&
                detail::TryParseInt(args[2], column) &&
                detail::TryParseInt(args[3], row))
            {
                int width = 0;
                int height = 0;
                if (detail::TryParseInt(args[4], width) &&
                    detail::TryParseInt(args[5], height))
                {
                    return TileTextureRegion(tile, LoadTexture(detail::Unquote(args[1])), column, row, width, height);
                }
            }

            if (name == "tilesolid" &&
                args.size() >= 2 &&
                detail::TryParseChar(args[0], tile) &&
                detail::TryParseBool(args[1], enabled))
            {
                return TileSolid(tile, enabled);
            }

            if (name == "tilevisible" &&
                args.size() >= 2 &&
                detail::TryParseChar(args[0], tile) &&
                detail::TryParseBool(args[1], enabled))
            {
                return TileVisible(tile, enabled);
            }

            if (name == "cell" &&
                args.size() >= 3 &&
                detail::TryParseInt(args[0], column) &&
                detail::TryParseInt(args[1], row) &&
                detail::TryParseChar(args[2], tile))
            {
                return Cell(column, row, tile);
            }

            Actor::Code(command);
            return const_cast<TileMapActor&>(*this);
        }

        TileMapActor& hontoCode(const std::string& command) const
        {
            return Code(command);
        }

        TileMapActor& hontoMap(const std::vector<std::string>& map) const
        {
            return Map(map);
        }

        TileMapActor& hontoTileSize(float width, float height) const
        {
            return TileSize(width, height);
        }

        TileMapActor& hontoTile(char tile, Color color, bool solid = false, bool visible = true) const
        {
            return Tile(tile, color, solid, visible);
        }

        TileMapActor& hontoTileTexture(char tile, const std::shared_ptr<Texture>& texture, Color tint = RGBA(255, 255, 255), bool solid = false, bool visible = true) const
        {
            return TileTexture(tile, texture, tint, solid, visible);
        }

        TileMapActor& hontoTileTextureRegion(
            char tile,
            const std::shared_ptr<Texture>& texture,
            int x,
            int y,
            int width,
            int height,
            Color tint = RGBA(255, 255, 255),
            bool solid = false,
            bool visible = true
        ) const
        {
            return TileTextureRegion(tile, texture, x, y, width, height, tint, solid, visible);
        }

        TileMapActor& hontoTileSolid(char tile, bool solid) const
        {
            return TileSolid(tile, solid);
        }

        TileMapActor& hontoTileVisible(char tile, bool visible) const
        {
            return TileVisible(tile, visible);
        }

        char hontoCell(int column, int row) const
        {
            return Cell(column, row);
        }

        TileMapActor& hontoCell(int column, int row, char tile) const
        {
            return Cell(column, row, tile);
        }

        bool hontoWorldToCell(const Vec2& point, int& column, int& row) const
        {
            return WorldToCell(point, column, row);
        }

        bool hontoCollides(const Actor& actor) const
        {
            return Collides(actor);
        }

        bool hontoIsSolidAt(const Vec2& point) const
        {
            return IsSolidAt(point);
        }

    private:
        std::shared_ptr<honto::TileMap> View() const
        {
            return std::dynamic_pointer_cast<honto::TileMap>(Share());
        }
    };

    inline bool Actor::TouchingMap(const TileMapActor& map) const
    {
        const auto tileMap = std::dynamic_pointer_cast<honto::TileMap>(map.Share());
        if (!(*this) || tileMap == nullptr)
        {
            return false;
        }

        return tileMap->CollidesRect(Position(), Size());
    }

    inline const Actor& Actor::CollideWithMap(const TileMapActor& map) const
    {
        if (m_State != nullptr)
        {
            m_State->collisionMap = std::dynamic_pointer_cast<honto::TileMap>(map.Share());
        }

        return EnsurePhysics();
    }

    class ParticleActor : public Actor
    {
    public:
        ParticleActor() = default;
        explicit ParticleActor(const Actor& actor)
            : Actor(actor)
        {
        }

        ParticleActor& EmissionRate(float particlesPerSecond) const
        {
            if (const auto view = View())
            {
                view->SetEmissionRate(particlesPerSecond);
            }

            return const_cast<ParticleActor&>(*this);
        }

        ParticleActor& SpawnArea(float width, float height) const
        {
            if (const auto view = View())
            {
                view->SetSpawnArea({ width, height });
            }

            return const_cast<ParticleActor&>(*this);
        }

        ParticleActor& VelocityRange(const Vec2& minimum, const Vec2& maximum) const
        {
            if (const auto view = View())
            {
                view->SetVelocityRange(minimum, maximum);
            }

            return const_cast<ParticleActor&>(*this);
        }

        ParticleActor& LifetimeRange(float minimumSeconds, float maximumSeconds) const
        {
            if (const auto view = View())
            {
                view->SetLifetimeRange(minimumSeconds, maximumSeconds);
            }

            return const_cast<ParticleActor&>(*this);
        }

        ParticleActor& SizeRange(float minimumSize, float maximumSize) const
        {
            if (const auto view = View())
            {
                view->SetSizeRange(minimumSize, maximumSize);
            }

            return const_cast<ParticleActor&>(*this);
        }

        ParticleActor& ColorRange(Color start, Color finish) const
        {
            if (const auto view = View())
            {
                view->SetColorRange(start, finish);
            }

            return const_cast<ParticleActor&>(*this);
        }

        ParticleActor& UseCamera(bool useCamera) const
        {
            if (const auto view = View())
            {
                view->SetUseCamera(useCamera);
            }

            return const_cast<ParticleActor&>(*this);
        }

        ParticleActor& Burst(int count) const
        {
            if (const auto view = View())
            {
                view->Burst(count);
            }

            return const_cast<ParticleActor&>(*this);
        }

        ParticleActor& Clear() const
        {
            if (const auto view = View())
            {
                view->ClearParticles();
            }

            return const_cast<ParticleActor&>(*this);
        }

        int Count() const
        {
            if (const auto view = View())
            {
                return view->GetParticleCount();
            }

            return 0;
        }

        ParticleActor& Code(const std::string& command) const
        {
            const detail::ParsedCommand parsed = detail::ParseCommand(command);
            if (!parsed.valid)
            {
                Actor::Code(command);
                return const_cast<ParticleActor&>(*this);
            }

            const std::string name = detail::NormalizeCommandName(parsed.name);
            const auto& args = parsed.args;

            float x = 0.0f;
            float y = 0.0f;
            float z = 0.0f;
            float w = 0.0f;
            bool enabled = false;
            int integer = 0;
            std::size_t consumed = 0;
            Color startColor {};
            Color finishColor {};

            if (name == "emissionrate" && !args.empty() && detail::TryParseFloat(args[0], x))
            {
                return EmissionRate(x);
            }

            if (name == "spawnarea" &&
                args.size() >= 2 &&
                detail::TryParseFloat(args[0], x) &&
                detail::TryParseFloat(args[1], y))
            {
                return SpawnArea(x, y);
            }

            if (name == "velocityrange" &&
                args.size() >= 4 &&
                detail::TryParseFloat(args[0], x) &&
                detail::TryParseFloat(args[1], y) &&
                detail::TryParseFloat(args[2], z) &&
                detail::TryParseFloat(args[3], w))
            {
                return VelocityRange({ x, y }, { z, w });
            }

            if (name == "lifetimerange" &&
                args.size() >= 2 &&
                detail::TryParseFloat(args[0], x) &&
                detail::TryParseFloat(args[1], y))
            {
                return LifetimeRange(x, y);
            }

            if (name == "sizerange" &&
                args.size() >= 2 &&
                detail::TryParseFloat(args[0], x) &&
                detail::TryParseFloat(args[1], y))
            {
                return SizeRange(x, y);
            }

            if (name == "colorrange" &&
                detail::TryParseLooseColor(args, 0, startColor, consumed))
            {
                std::vector<std::string> remainder(args.begin() + static_cast<std::ptrdiff_t>(consumed), args.end());
                std::size_t finishConsumed = 0;
                if (detail::TryParseLooseColor(remainder, 0, finishColor, finishConsumed))
                {
                    return ColorRange(startColor, finishColor);
                }
            }

            if (name == "usecamera" && !args.empty() && detail::TryParseBool(args[0], enabled))
            {
                return UseCamera(enabled);
            }

            if (name == "burst" && !args.empty() && detail::TryParseInt(args[0], integer))
            {
                return Burst(integer);
            }

            if (name == "clear")
            {
                return Clear();
            }

            Actor::Code(command);
            return const_cast<ParticleActor&>(*this);
        }

        ParticleActor& hontoCode(const std::string& command) const
        {
            return Code(command);
        }

        ParticleActor& hontoEmissionRate(float particlesPerSecond) const
        {
            return EmissionRate(particlesPerSecond);
        }

        ParticleActor& hontoSpawnArea(float width, float height) const
        {
            return SpawnArea(width, height);
        }

        ParticleActor& hontoVelocityRange(const Vec2& minimum, const Vec2& maximum) const
        {
            return VelocityRange(minimum, maximum);
        }

        ParticleActor& hontoLifetimeRange(float minimumSeconds, float maximumSeconds) const
        {
            return LifetimeRange(minimumSeconds, maximumSeconds);
        }

        ParticleActor& hontoSizeRange(float minimumSize, float maximumSize) const
        {
            return SizeRange(minimumSize, maximumSize);
        }

        ParticleActor& hontoColorRange(Color start, Color finish) const
        {
            return ColorRange(start, finish);
        }

        ParticleActor& hontoUseCamera(bool useCamera) const
        {
            return UseCamera(useCamera);
        }

        ParticleActor& hontoBurst(int count) const
        {
            return Burst(count);
        }

        ParticleActor& hontoClear() const
        {
            return Clear();
        }

        int hontoCount() const
        {
            return Count();
        }

    private:
        std::shared_ptr<honto::ParticleEmitter> View() const
        {
            return std::dynamic_pointer_cast<honto::ParticleEmitter>(Share());
        }
    };

    class RaycastActor : public Actor
    {
    public:
        RaycastActor() = default;
        explicit RaycastActor(const Actor& actor)
            : Actor(actor)
        {
        }

        RaycastActor& hontoMap(const std::vector<std::string>& map)
        {
            if (const auto view = View())
            {
                view->SetMap(map);
            }

            return *this;
        }

        RaycastActor& hontoPlayer(float x, float y, float angleRadians)
        {
            if (const auto view = View())
            {
                view->SetPlayer({ x, y }, angleRadians);
            }

            return *this;
        }

        RaycastActor& hontoPlayer(const Vec2& position, float angleRadians)
        {
            if (const auto view = View())
            {
                view->SetPlayer(position, angleRadians);
            }

            return *this;
        }

        Vec2 PlayerPosition() const
        {
            if (const auto view = View())
            {
                return view->GetPlayerPosition();
            }

            return {};
        }

        float PlayerAngle() const
        {
            if (const auto view = View())
            {
                return view->GetPlayerAngle();
            }

            return 0.0f;
        }

        Vec2 hontoPlayerPosition() const
        {
            return PlayerPosition();
        }

        float hontoPlayerAngle() const
        {
            return PlayerAngle();
        }

        RaycastActor& hontoViewDegrees(float degrees)
        {
            if (const auto view = View())
            {
                view->SetFieldOfView(degrees * 0.0174532925f);
            }

            return *this;
        }

        RaycastActor& hontoMoveSpeed(float speed)
        {
            if (const auto view = View())
            {
                view->SetMoveSpeed(speed);
            }

            return *this;
        }

        RaycastActor& hontoTurnSpeed(float speed)
        {
            if (const auto view = View())
            {
                view->SetTurnSpeed(speed);
            }

            return *this;
        }

        RaycastActor& hontoRunMultiplier(float multiplier)
        {
            if (const auto view = View())
            {
                view->SetRunMultiplier(multiplier);
            }

            return *this;
        }

        RaycastActor& hontoFloor(Color color)
        {
            if (const auto view = View())
            {
                view->SetFloorColor(color);
            }

            return *this;
        }

        RaycastActor& hontoDoor(char cell, Color color, float openSeconds = 0.8f, float holdSeconds = 1.6f)
        {
            if (const auto view = View())
            {
                view->SetDoor(cell, color, openSeconds, holdSeconds);
            }

            return *this;
        }

        RaycastActor& hontoDoorTexture(char cell, const std::shared_ptr<Texture>& texture)
        {
            if (const auto view = View())
            {
                view->SetDoorTexture(cell, texture);
            }

            return *this;
        }

        RaycastActor& hontoThing(
            const std::string& name,
            float x,
            float y,
            float width,
            float height,
            Color tint = RGBA(255, 255, 255),
            float bobAmount = 0.0f,
            float bobSpeed = 0.0f
        )
        {
            if (const auto view = View())
            {
                view->AddThing(name, { x, y }, { width, height }, tint, nullptr, bobAmount, bobSpeed);
            }

            return *this;
        }

        RaycastActor& hontoThingTexture(
            const std::string& name,
            float x,
            float y,
            float width,
            float height,
            const std::shared_ptr<Texture>& texture,
            Color tint = RGBA(255, 255, 255),
            float bobAmount = 0.0f,
            float bobSpeed = 0.0f
        )
        {
            if (const auto view = View())
            {
                view->AddThing(name, { x, y }, { width, height }, tint, texture, bobAmount, bobSpeed);
            }

            return *this;
        }

        RaycastActor& hontoThingTexture(
            const std::string& name,
            float x,
            float y,
            float width,
            float height,
            const std::string& path,
            Color tint = RGBA(255, 255, 255),
            float bobAmount = 0.0f,
            float bobSpeed = 0.0f
        )
        {
            return hontoThingTexture(name, x, y, width, height, LoadTexture(path), tint, bobAmount, bobSpeed);
        }

        RaycastActor& hontoClearThings()
        {
            if (const auto view = View())
            {
                view->ClearThings();
            }

            return *this;
        }
        RaycastActor& hontoCeiling(Color color)
        {
            if (const auto view = View())
            {
                view->SetCeilingColor(color);
            }

            return *this;
        }

        RaycastActor& hontoWall(char cell, Color color)
        {
            if (const auto view = View())
            {
                view->SetWallColor(cell, color);
            }

            return *this;
        }

        RaycastActor& hontoWallTexture(char cell, const std::shared_ptr<Texture>& texture)
        {
            if (const auto view = View())
            {
                view->SetWallTexture(cell, texture);
            }

            return *this;
        }

        RaycastActor& hontoDoomControls(float moveSpeed = 3.0f, float turnSpeed = 2.0f)
        {
            if (const auto view = View())
            {
                view->SetMoveSpeed(moveSpeed);
                view->SetTurnSpeed(turnSpeed);
                view->EnableDoomControls(true);
            }

            return *this;
        }

        RaycastActor& hontoWeapon(const std::shared_ptr<Texture>& texture, float width, float height, Color tint = RGBA(255, 255, 255))
        {
            if (const auto view = View())
            {
                view->SetWeapon(texture, { width, height }, tint);
            }

            return *this;
        }

        RaycastActor& hontoWeapon(const std::string& path, float width, float height, Color tint = RGBA(255, 255, 255))
        {
            return hontoWeapon(LoadTexture(path), width, height, tint);
        }

        RaycastActor& hontoWeaponBob(float amount, float speed)
        {
            if (const auto view = View())
            {
                view->SetWeaponBobbing(amount, speed);
            }

            return *this;
        }

        RaycastActor& hontoFog(Color color, float strength = 0.35f)
        {
            if (const auto view = View())
            {
                view->SetFog(color, strength);
            }

            return *this;
        }

        RaycastActor& hontoMiniMap(bool enabled = true, float scale = 8.0f)
        {
            if (const auto view = View())
            {
                view->SetMiniMapEnabled(enabled, scale);
            }

            return *this;
        }

        RaycastActor& hontoMaxDistance(float distance)
        {
            if (const auto view = View())
            {
                view->SetMaxDistance(distance);
            }

            return *this;
        }

        RaycastActor& Code(const std::string& command)
        {
            const detail::ParsedCommand parsed = detail::ParseCommand(command);
            if (!parsed.valid)
            {
                Actor::Code(command);
                return *this;
            }

            const std::string name = detail::NormalizeCommandName(parsed.name);
            const auto& args = parsed.args;

            float x = 0.0f;
            float y = 0.0f;
            float z = 0.0f;
            float w = 0.0f;
            char cell = '\0';
            std::size_t consumed = 0;
            Color color {};

            if (name == "map" && !args.empty())
            {
                return hontoMap(detail::ParseMapRows(args[0]));
            }

            if (name == "player" &&
                args.size() >= 3 &&
                detail::TryParseFloat(args[0], x) &&
                detail::TryParseFloat(args[1], y) &&
                detail::TryParseFloat(args[2], z))
            {
                return hontoPlayer(x, y, z);
            }

            if (name == "viewdegrees" && !args.empty() && detail::TryParseFloat(args[0], x))
            {
                return hontoViewDegrees(x);
            }

            if (name == "movespeed" && !args.empty() && detail::TryParseFloat(args[0], x))
            {
                return hontoMoveSpeed(x);
            }

            if (name == "turnspeed" && !args.empty() && detail::TryParseFloat(args[0], x))
            {
                return hontoTurnSpeed(x);
            }

            if (name == "runmultiplier" && !args.empty() && detail::TryParseFloat(args[0], x))
            {
                return hontoRunMultiplier(x);
            }

            if ((name == "floor" || name == "ceiling" || name == "fog") &&
                detail::TryParseLooseColor(args, 0, color, consumed))
            {
                if (name == "floor")
                {
                    return hontoFloor(color);
                }

                if (name == "ceiling")
                {
                    return hontoCeiling(color);
                }

                float strength = 0.35f;
                if (consumed < args.size())
                {
                    detail::TryParseFloat(args[consumed], strength);
                }

                return hontoFog(color, strength);
            }

            if ((name == "wall" || name == "door") &&
                args.size() >= 2 &&
                detail::TryParseChar(args[0], cell) &&
                detail::TryParseLooseColor(args, 1, color, consumed))
            {
                if (name == "wall")
                {
                    return hontoWall(cell, color);
                }

                float openSeconds = 0.8f;
                float holdSeconds = 1.6f;
                std::size_t next = 1 + consumed;
                if (next < args.size())
                {
                    detail::TryParseFloat(args[next], openSeconds);
                    ++next;
                }
                if (next < args.size())
                {
                    detail::TryParseFloat(args[next], holdSeconds);
                }

                return hontoDoor(cell, color, openSeconds, holdSeconds);
            }

            if (name == "walltexture" &&
                args.size() >= 2 &&
                detail::TryParseChar(args[0], cell))
            {
                return hontoWallTexture(cell, LoadTexture(detail::Unquote(args[1])));
            }

            if (name == "doortexture" &&
                args.size() >= 2 &&
                detail::TryParseChar(args[0], cell))
            {
                return hontoDoorTexture(cell, LoadTexture(detail::Unquote(args[1])));
            }

            if (name == "thing" && args.size() >= 5 &&
                detail::TryParseFloat(args[1], x) &&
                detail::TryParseFloat(args[2], y) &&
                detail::TryParseFloat(args[3], z) &&
                detail::TryParseFloat(args[4], w))
            {
                Color tint = RGBA(255, 255, 255);
                float bobAmount = 0.0f;
                float bobSpeed = 0.0f;
                std::size_t next = 5;
                if (next < args.size() && detail::TryParseLooseColor(args, next, tint, consumed))
                {
                    next += consumed;
                }
                if (next < args.size())
                {
                    detail::TryParseFloat(args[next], bobAmount);
                    ++next;
                }
                if (next < args.size())
                {
                    detail::TryParseFloat(args[next], bobSpeed);
                }

                return hontoThing(detail::Unquote(args[0]), x, y, z, w, tint, bobAmount, bobSpeed);
            }

            if (name == "thingtexture" && args.size() >= 6 &&
                detail::TryParseFloat(args[1], x) &&
                detail::TryParseFloat(args[2], y) &&
                detail::TryParseFloat(args[3], z) &&
                detail::TryParseFloat(args[4], w))
            {
                Color tint = RGBA(255, 255, 255);
                float bobAmount = 0.0f;
                float bobSpeed = 0.0f;
                std::size_t next = 6;
                if (next < args.size() && detail::TryParseLooseColor(args, next, tint, consumed))
                {
                    next += consumed;
                }
                if (next < args.size())
                {
                    detail::TryParseFloat(args[next], bobAmount);
                    ++next;
                }
                if (next < args.size())
                {
                    detail::TryParseFloat(args[next], bobSpeed);
                }

                return hontoThingTexture(
                    detail::Unquote(args[0]),
                    x,
                    y,
                    z,
                    w,
                    LoadTexture(detail::Unquote(args[5])),
                    tint,
                    bobAmount,
                    bobSpeed
                );
            }

            if (name == "clearthings")
            {
                return hontoClearThings();
            }

            if (name == "doomcontrols")
            {
                float moveSpeed = 3.0f;
                float turnSpeed = 2.0f;
                if (!args.empty())
                {
                    detail::TryParseFloat(args[0], moveSpeed);
                }
                if (args.size() >= 2)
                {
                    detail::TryParseFloat(args[1], turnSpeed);
                }

                return hontoDoomControls(moveSpeed, turnSpeed);
            }

            if (name == "weapon" &&
                args.size() >= 3 &&
                detail::TryParseFloat(args[1], x) &&
                detail::TryParseFloat(args[2], y))
            {
                Color tint = RGBA(255, 255, 255);
                if (args.size() > 3)
                {
                    detail::TryParseLooseColor(args, 3, tint, consumed);
                }

                return hontoWeapon(LoadTexture(detail::Unquote(args[0])), x, y, tint);
            }

            if (name == "weaponbob" &&
                args.size() >= 2 &&
                detail::TryParseFloat(args[0], x) &&
                detail::TryParseFloat(args[1], y))
            {
                return hontoWeaponBob(x, y);
            }

            if (name == "minimap")
            {
                bool showMap = true;
                float scale = 8.0f;
                if (!args.empty())
                {
                    detail::TryParseBool(args[0], showMap);
                }
                if (args.size() >= 2)
                {
                    detail::TryParseFloat(args[1], scale);
                }

                return hontoMiniMap(showMap, scale);
            }

            if (name == "maxdistance" && !args.empty() && detail::TryParseFloat(args[0], x))
            {
                return hontoMaxDistance(x);
            }

            Actor::Code(command);
            return *this;
        }

        RaycastActor& hontoCode(const std::string& command)
        {
            return Code(command);
        }

    private:
        std::shared_ptr<honto::RaycastView> View() const
        {
            return std::dynamic_pointer_cast<honto::RaycastView>(Share());
        }
    };

    class Stage
    {
    public:
        Stage(HonTo::Scene* scene, std::shared_ptr<detail::StageState> state)
            : m_Scene(scene),
              m_State(std::move(state))
        {
            if (m_State != nullptr)
            {
                m_State->scene = m_Scene;
            }
        }

        Vec2 VisibleSize() const
        {
            return HonTo::VisibleSize();
        }

        Vec2 hontoVisibleSize() const
        {
            return VisibleSize();
        }

        Stage& CameraAt(const Vec2& position, float zoom = 1.0f)
        {
            if (auto* renderer = honto::Director::Get().GetRenderer())
            {
                renderer->SetCamera(position, zoom);
            }

            return *this;
        }

        Stage& CameraAt(float x, float y, float zoom = 1.0f)
        {
            return CameraAt({ x, y }, zoom);
        }

        Stage& CameraReset()
        {
            if (auto* renderer = honto::Director::Get().GetRenderer())
            {
                renderer->ResetCamera();
            }

            return *this;
        }

        void CameraFollow(const Actor& actor, float zoom = 1.0f)
        {
            EveryFrame(
                [actor, zoom](float)
                {
                    if (!actor)
                    {
                        return;
                    }

                    if (auto* renderer = honto::Director::Get().GetRenderer())
                    {
                        const Vec2 visible = HonTo::VisibleSize();
                        const Vec2 cameraHalf = visible / (2.0f * std::max(0.01f, zoom));
                        const Vec2 target = actor.Position() + (actor.Size() * 0.5f) - cameraHalf;
                        renderer->SetCamera(target, zoom);
                    }
                }
            );
        }

        void CameraFollowSmooth(const Actor& actor, float zoom = 1.0f, float responsiveness = 8.0f)
        {
            auto current = std::make_shared<Vec2>();
            auto initialized = std::make_shared<bool>(false);

            EveryFrame(
                [actor, zoom, responsiveness, current, initialized](float deltaTime)
                {
                    if (!actor)
                    {
                        return;
                    }

                    if (auto* renderer = honto::Director::Get().GetRenderer())
                    {
                        const Vec2 visible = HonTo::VisibleSize();
                        const Vec2 cameraHalf = visible / (2.0f * std::max(0.01f, zoom));
                        const Vec2 target = actor.Position() + (actor.Size() * 0.5f) - cameraHalf;
                        if (!*initialized)
                        {
                            *current = target;
                            *initialized = true;
                        }

                        const float blend = std::clamp(std::max(0.0f, responsiveness) * deltaTime, 0.0f, 1.0f);
                        *current = detail::Lerp(*current, target, blend);
                        renderer->SetCamera(*current, zoom);
                    }
                }
            );
        }

        void CameraShake(float strength, float seconds, float frequency = 18.0f) const
        {
            const float duration = std::max(0.01f, seconds);
            auto remaining = std::make_shared<float>(duration);
            auto time = std::make_shared<float>(0.0f);
            auto previousOffset = std::make_shared<Vec2>();

            const_cast<Stage&>(*this).EveryFrame(
                [strength, duration, frequency, remaining, time, previousOffset](float deltaTime)
                {
                    if (*remaining <= 0.0f)
                    {
                        return;
                    }

                    if (auto* renderer = honto::Director::Get().GetRenderer())
                    {
                        const Vec2 base = renderer->GetCameraPosition() - *previousOffset;
                        const float zoom = renderer->GetCameraZoom();

                        *time += deltaTime;
                        *remaining -= deltaTime;

                        if (*remaining > 0.0f)
                        {
                            const float fade = std::clamp(*remaining / duration, 0.0f, 1.0f);
                            const Vec2 offset {
                                std::sin(*time * frequency * 6.2831853071f) * strength * fade,
                                std::cos(*time * frequency * 4.7123889803f) * strength * 0.6f * fade
                            };
                            renderer->SetCamera(base + offset, zoom);
                            *previousOffset = offset;
                        }
                        else
                        {
                            renderer->SetCamera(base, zoom);
                            *previousOffset = {};
                        }
                    }
                }
            );
        }

        Stage& hontoCameraAt(const Vec2& position, float zoom = 1.0f)
        {
            return CameraAt(position, zoom);
        }

        Stage& hontoCameraAt(float x, float y, float zoom = 1.0f)
        {
            return CameraAt(x, y, zoom);
        }

        Stage& hontoCameraReset()
        {
            return CameraReset();
        }

        void hontoCameraFollow(const Actor& actor, float zoom = 1.0f)
        {
            CameraFollow(actor, zoom);
        }

        void hontoCameraFollowSmooth(const Actor& actor, float zoom = 1.0f, float responsiveness = 8.0f)
        {
            CameraFollowSmooth(actor, zoom, responsiveness);
        }

        void hontoCameraShake(float strength, float seconds, float frequency = 18.0f) const
        {
            CameraShake(strength, seconds, frequency);
        }

        Stage& Gravity(float x, float y)
        {
            return Gravity({ x, y });
        }

        Stage& Gravity(const Vec2& gravity)
        {
            if (m_State != nullptr)
            {
                m_State->gravity = gravity;
            }

            return *this;
        }

        Stage& hontoGravity(float x, float y)
        {
            return Gravity(x, y);
        }

        Stage& hontoGravity(const Vec2& gravity)
        {
            return Gravity(gravity);
        }

        Vec2 GravityValue() const
        {
            if (m_State == nullptr)
            {
                return {};
            }

            return m_State->gravity;
        }

        Stage& WindowOpacity(float opacity) const
        {
            if (auto* window = honto::Director::Get().GetWindow())
            {
                window->SetOpacity(opacity);
            }

            return const_cast<Stage&>(*this);
        }

        Stage& WindowBorderless(bool enabled = true) const
        {
            if (auto* window = honto::Director::Get().GetWindow())
            {
                window->SetBorderless(enabled);
            }

            return const_cast<Stage&>(*this);
        }

        Stage& WindowResizable(bool enabled = true) const
        {
            if (auto* window = honto::Director::Get().GetWindow())
            {
                window->SetResizable(enabled);
            }

            return const_cast<Stage&>(*this);
        }

        Stage& WindowTopMost(bool enabled = true) const
        {
            if (auto* window = honto::Director::Get().GetWindow())
            {
                window->SetAlwaysOnTop(enabled);
            }

            return const_cast<Stage&>(*this);
        }

        Stage& WindowSize(int width, int height) const
        {
            if (auto* window = honto::Director::Get().GetWindow())
            {
                window->SetClientSize(width, height);
            }

            return const_cast<Stage&>(*this);
        }

        Stage& WindowPosition(int x, int y) const
        {
            if (auto* window = honto::Director::Get().GetWindow())
            {
                window->SetPosition(x, y);
            }

            return const_cast<Stage&>(*this);
        }

        Stage& WindowCenter() const
        {
            if (auto* window = honto::Director::Get().GetWindow())
            {
                window->Center();
            }

            return const_cast<Stage&>(*this);
        }

        Stage& hontoWindowOpacity(float opacity) const
        {
            return WindowOpacity(opacity);
        }

        Stage& hontoWindowBorderless(bool enabled = true) const
        {
            return WindowBorderless(enabled);
        }

        Stage& hontoWindowResizable(bool enabled = true) const
        {
            return WindowResizable(enabled);
        }

        Stage& hontoWindowTopMost(bool enabled = true) const
        {
            return WindowTopMost(enabled);
        }

        Stage& hontoWindowSize(int width, int height) const
        {
            return WindowSize(width, height);
        }

        Stage& hontoWindowPosition(int x, int y) const
        {
            return WindowPosition(x, y);
        }

        Stage& hontoWindowCenter() const
        {
            return WindowCenter();
        }

        Vec2 MousePosition() const
        {
            return HonTo::MousePosition();
        }

        bool HasMouse() const
        {
            return HonTo::HasMouse();
        }

        bool MouseDown(Mouse button) const
        {
            return HonTo::MouseDown(button);
        }

        bool MousePressed(Mouse button) const
        {
            return HonTo::MousePressed(button);
        }

        Vec2 hontoMousePosition() const
        {
            return MousePosition();
        }

        bool hontoHasMouse() const
        {
            return HasMouse();
        }

        bool hontoMouseDown(Mouse button) const
        {
            return MouseDown(button);
        }

        bool hontoMousePressed(Mouse button) const
        {
            return MousePressed(button);
        }

        Actor Background(Color color)
        {
            return Fill(VisibleSize(), color);
        }

        Actor Background(std::uint8_t r, std::uint8_t g, std::uint8_t b, std::uint8_t a = 255)
        {
            return Background(RGBA(r, g, b, a));
        }

        Actor hontoBackground(Color color)
        {
            return Background(color);
        }

        Actor hontoBackground(std::uint8_t r, std::uint8_t g, std::uint8_t b, std::uint8_t a = 255)
        {
            return Background(r, g, b, a);
        }

        Actor Box(float width, float height, Color color = RGBA(255, 255, 255))
        {
            return Box({}, width, height, color);
        }

        Actor Box(const std::string& name, float width, float height, Color color = RGBA(255, 255, 255))
        {
            auto actor = CreateActor(name, honto::Sprite::CreateSolid({ width, height }, color));
            actor.Size(width, height).Paint(color);
            return actor;
        }

        Actor hontoBox(float width, float height, Color color = RGBA(255, 255, 255))
        {
            return Box(width, height, color);
        }

        Actor hontoBox(const std::string& name, float width, float height, Color color = RGBA(255, 255, 255))
        {
            return Box(name, width, height, color);
        }

        Actor Image(const std::string& name, const std::shared_ptr<Texture>& texture, float width, float height, Color tint = RGBA(255, 255, 255))
        {
            auto actor = CreateActor(name, honto::Sprite::CreateTextured({ width, height }, texture, tint));
            actor.Size(width, height).Paint(tint).UseTexture(texture);
            return actor;
        }

        Actor Image(const std::string& name, const std::string& path, float width, float height, Color tint = RGBA(255, 255, 255))
        {
            return Image(name, LoadTexture(path), width, height, tint);
        }

        Actor Checker(
            const std::string& name,
            float width,
            float height,
            Color a,
            Color b,
            int cellSize = 8,
            Color tint = RGBA(255, 255, 255)
        )
        {
            return Image(name, CheckerTexture(static_cast<int>(width), static_cast<int>(height), a, b, cellSize), width, height, tint);
        }

        Actor hontoImage(const std::string& name, const std::shared_ptr<Texture>& texture, float width, float height, Color tint = RGBA(255, 255, 255))
        {
            return Image(name, texture, width, height, tint);
        }

        Actor hontoImage(const std::string& name, const std::string& path, float width, float height, Color tint = RGBA(255, 255, 255))
        {
            return Image(name, path, width, height, tint);
        }

        Actor hontoChecker(
            const std::string& name,
            float width,
            float height,
            Color a,
            Color b,
            int cellSize = 8,
            Color tint = RGBA(255, 255, 255)
        )
        {
            return Checker(name, width, height, a, b, cellSize, tint);
        }

        Actor Fill(float width, float height, Color color)
        {
            return Fill({}, width, height, color);
        }

        Actor Fill(const std::string& name, float width, float height, Color color)
        {
            auto actor = CreateActor(name, honto::LayerColor::Create(color, width, height));
            actor.Size(width, height).Paint(color);
            return actor;
        }

        Actor Fill(const Vec2& size, Color color)
        {
            return Fill({}, size.x, size.y, color);
        }

        Actor Fill(const std::string& name, const Vec2& size, Color color)
        {
            return Fill(name, size.x, size.y, color);
        }

        Actor hontoFill(float width, float height, Color color)
        {
            return Fill(width, height, color);
        }

        Actor hontoFill(const std::string& name, float width, float height, Color color)
        {
            return Fill(name, width, height, color);
        }

        Actor hontoFill(const Vec2& size, Color color)
        {
            return Fill(size, color);
        }

        Actor hontoFill(const std::string& name, const Vec2& size, Color color)
        {
            return Fill(name, size, color);
        }

        Actor Outline(float width, float height, Color color, int thickness = 1)
        {
            return Outline({}, width, height, color, thickness);
        }

        Actor Outline(const std::string& name, float width, float height, Color color, int thickness = 1)
        {
            auto frame = std::make_shared<detail::FrameNode>();
            if (frame != nullptr)
            {
                frame->Init();
                frame->SetContentSize(width, height);
                frame->SetColor(color);
                frame->SetThickness(thickness);
            }

            auto actor = CreateActor(name, frame);
            actor.Size(width, height).Paint(color).Thickness(thickness);
            return actor;
        }

        Actor hontoOutline(float width, float height, Color color, int thickness = 1)
        {
            return Outline(width, height, color, thickness);
        }

        Actor hontoOutline(const std::string& name, float width, float height, Color color, int thickness = 1)
        {
            return Outline(name, width, height, color, thickness);
        }

        TileMapActor TileMap(const std::string& name, const std::vector<std::string>& map, float tileWidth, float tileHeight)
        {
            auto tileMap = honto::TileMap::Create(map, tileWidth, tileHeight);
            return TileMapActor(CreateActor(name, tileMap));
        }

        TileMapActor TileMap(const std::string& name, const Level& level)
        {
            return TileMap(name, level.map, level.tileSize.x, level.tileSize.y);
        }

        TileMapActor hontoTileMap(const std::string& name, const std::vector<std::string>& map, float tileWidth, float tileHeight)
        {
            return TileMap(name, map, tileWidth, tileHeight);
        }

        TileMapActor hontoTileMap(const std::string& name, const Level& level)
        {
            return TileMap(name, level);
        }

        Actor Text(
            const std::string& name,
            const std::string& text,
            Color color = RGBA(255, 255, 255),
            int glyphScale = 1,
            bool useCamera = false
        )
        {
            auto actor = CreateActor(name, honto::Label::Create(text, color, glyphScale, useCamera));
            actor.TextValue(text).Paint(color).TextScale(glyphScale).UseCamera(useCamera);
            return actor;
        }

        Actor hontoText(
            const std::string& name,
            const std::string& text,
            Color color = RGBA(255, 255, 255),
            int glyphScale = 1,
            bool useCamera = false
        )
        {
            return Text(name, text, color, glyphScale, useCamera);
        }

        Actor Bar(
            const std::string& name,
            float width,
            float height,
            float value = 1.0f,
            Color fill = RGBA(92, 220, 128),
            Color background = RGBA(18, 24, 36, 180),
            Color border = RGBA(255, 255, 255),
            bool useCamera = false
        )
        {
            auto actor = CreateActor(name, honto::ProgressBar::Create(width, height, value, useCamera));
            actor.Size(width, height).BarValue(value).BarColors(fill, background, border).UseCamera(useCamera);
            return actor;
        }

        Actor hontoBar(
            const std::string& name,
            float width,
            float height,
            float value = 1.0f,
            Color fill = RGBA(92, 220, 128),
            Color background = RGBA(18, 24, 36, 180),
            Color border = RGBA(255, 255, 255),
            bool useCamera = false
        )
        {
            return Bar(name, width, height, value, fill, background, border, useCamera);
        }

        Actor Button(
            const std::string& name,
            const std::string& text,
            float width,
            float height,
            Color normal = RGBA(44, 62, 96),
            Color hover = RGBA(68, 94, 144),
            Color pressed = RGBA(92, 128, 188),
            Color border = RGBA(236, 245, 255),
            Color textColor = RGBA(255, 255, 255),
            int glyphScale = 1,
            bool useCamera = false
        )
        {
            auto actor = CreateActor(name, honto::Button::Create(text, width, height, useCamera));
            actor
                .Size(width, height)
                .TextValue(text)
                .TextScale(glyphScale)
                .ButtonColors(normal, hover, pressed, border)
                .ButtonTextColor(textColor)
                .UseCamera(useCamera)
                .ButtonState(false, false);

            EveryFrame(
                [actor](float)
                {
                    const bool hovered = HonTo::HasMouse() && actor.ContainsPoint(HonTo::MousePosition());
                    const bool pressedNow = hovered && HonTo::MouseDown(Mouse::Left);
                    actor.ButtonState(hovered, pressedNow);
                }
            );

            return actor;
        }

        Actor hontoButton(
            const std::string& name,
            const std::string& text,
            float width,
            float height,
            Color normal = RGBA(44, 62, 96),
            Color hover = RGBA(68, 94, 144),
            Color pressed = RGBA(92, 128, 188),
            Color border = RGBA(236, 245, 255),
            Color textColor = RGBA(255, 255, 255),
            int glyphScale = 1,
            bool useCamera = false
        )
        {
            return Button(name, text, width, height, normal, hover, pressed, border, textColor, glyphScale, useCamera);
        }

        Actor Trigger(
            const std::string& name,
            float width,
            float height,
            bool visible = false,
            Color color = RGBA(255, 214, 96, 96)
        )
        {
            auto actor = Fill(name, width, height, color);
            if (!visible)
            {
                actor.Hide();
            }

            return actor;
        }

        Actor hontoTrigger(
            const std::string& name,
            float width,
            float height,
            bool visible = false,
            Color color = RGBA(255, 214, 96, 96)
        )
        {
            return Trigger(name, width, height, visible, color);
        }

        ParticleActor Particles(const std::string& name, float width, float height)
        {
            return ParticleActor(CreateActor(name, honto::ParticleEmitter::Create(width, height)));
        }

        ParticleActor hontoParticles(const std::string& name, float width, float height)
        {
            return Particles(name, width, height);
        }

        RaycastActor Raycast(const std::string& name, float width, float height)
        {
            auto view = std::make_shared<honto::RaycastView>();
            if (view != nullptr)
            {
                view->Init();
                view->SetContentSize(width, height);
            }

            return RaycastActor(CreateActor(name, view));
        }

        RaycastActor hontoRaycast(const std::string& name, float width, float height)
        {
            return Raycast(name, width, height);
        }

        Actor Find(const std::string& name) const
        {
            if (m_State == nullptr)
            {
                return {};
            }

            const auto found = m_State->namedActors.find(name);
            if (found == m_State->namedActors.end())
            {
                return {};
            }

            return Actor(found->second);
        }

        Actor hontoFind(const std::string& name) const
        {
            return Find(name);
        }

        bool PlaySound(const std::string& path, bool loop = false) const
        {
            return HonTo::PlaySound(path, loop);
        }

        bool PlayAlias(const std::string& alias, bool loop = false) const
        {
            return HonTo::PlayAlias(alias, loop);
        }

        bool PlayOnBus(const std::string& bus, const std::string& path, bool loop = false) const
        {
            return HonTo::PlayOnBus(bus, path, loop);
        }

        bool PlayMusic(const std::string& path, bool loop = true) const
        {
            return HonTo::PlayMusic(path, loop);
        }

        bool PlayEffect(const std::string& path) const
        {
            return HonTo::PlayEffect(path);
        }

        void StopAudio() const
        {
            HonTo::StopAudio();
        }

        void StopAudioBus(const std::string& bus) const
        {
            HonTo::StopAudioBus(bus);
        }

        void SetMasterVolume(float volume) const
        {
            HonTo::SetMasterVolume(volume);
        }

        float MasterVolume() const
        {
            return HonTo::MasterVolume();
        }

        void SetBusVolume(const std::string& bus, float volume) const
        {
            HonTo::SetBusVolume(bus, volume);
        }

        float BusVolume(const std::string& bus) const
        {
            return HonTo::BusVolume(bus);
        }

        void PlayTone(int frequency, int durationMs) const
        {
            HonTo::PlayTone(frequency, durationMs);
        }

        bool hontoPlaySound(const std::string& path, bool loop = false) const
        {
            return PlaySound(path, loop);
        }

        bool hontoPlayAlias(const std::string& alias, bool loop = false) const
        {
            return PlayAlias(alias, loop);
        }

        bool hontoPlayOnBus(const std::string& bus, const std::string& path, bool loop = false) const
        {
            return PlayOnBus(bus, path, loop);
        }

        bool hontoPlayMusic(const std::string& path, bool loop = true) const
        {
            return PlayMusic(path, loop);
        }

        bool hontoPlayEffect(const std::string& path) const
        {
            return PlayEffect(path);
        }

        void hontoStopAudio() const
        {
            StopAudio();
        }

        void hontoStopAudioBus(const std::string& bus) const
        {
            StopAudioBus(bus);
        }

        void hontoSetMasterVolume(float volume) const
        {
            SetMasterVolume(volume);
        }

        float hontoMasterVolume() const
        {
            return MasterVolume();
        }

        void hontoSetBusVolume(const std::string& bus, float volume) const
        {
            SetBusVolume(bus, volume);
        }

        float hontoBusVolume(const std::string& bus) const
        {
            return BusVolume(bus);
        }

        void hontoPlayTone(int frequency, int durationMs) const
        {
            PlayTone(frequency, durationMs);
        }

        Stage& Code(const std::string& command) const
        {
            const detail::ParsedCommand parsed = detail::ParseCommand(command);
            if (!parsed.valid)
            {
                return const_cast<Stage&>(*this);
            }

            const std::string name = detail::NormalizeCommandName(parsed.name);
            const auto& args = parsed.args;

            float x = 0.0f;
            float y = 0.0f;
            float z = 0.0f;
            bool enabled = false;
            int integer = 0;
            std::size_t consumed = 0;
            Color color {};

            if ((name == "background" || name == "clear") &&
                detail::TryParseColor(args, 0, 1, color, consumed) &&
                consumed == args.size())
            {
                const_cast<Stage&>(*this).Background(color);
                return const_cast<Stage&>(*this);
            }

            if (name == "gravity" && args.size() >= 2 &&
                detail::TryParseFloat(args[0], x) &&
                detail::TryParseFloat(args[1], y))
            {
                return const_cast<Stage&>(*this).Gravity(x, y);
            }

            if (name == "cameraat" && args.size() >= 2 &&
                detail::TryParseFloat(args[0], x) &&
                detail::TryParseFloat(args[1], y))
            {
                if (args.size() >= 3 && detail::TryParseFloat(args[2], z))
                {
                    return const_cast<Stage&>(*this).CameraAt(x, y, z);
                }

                return const_cast<Stage&>(*this).CameraAt(x, y);
            }

            if (name == "camerareset")
            {
                return const_cast<Stage&>(*this).CameraReset();
            }

            if (name == "camerashake" && args.size() >= 2 &&
                detail::TryParseFloat(args[0], x) &&
                detail::TryParseFloat(args[1], y))
            {
                if (args.size() >= 3 && detail::TryParseFloat(args[2], z))
                {
                    CameraShake(x, y, z);
                }
                else
                {
                    CameraShake(x, y);
                }

                return const_cast<Stage&>(*this);
            }

            if ((name == "camerafollow" || name == "camerafollowsmooth") && !args.empty())
            {
                const Actor actor = Find(detail::Unquote(args[0]));
                if (actor)
                {
                    float zoom = 1.0f;
                    float responsiveness = 8.0f;
                    if (args.size() >= 2)
                    {
                        detail::TryParseFloat(args[1], zoom);
                    }

                    if (name == "camerafollowsmooth")
                    {
                        if (args.size() >= 3)
                        {
                            detail::TryParseFloat(args[2], responsiveness);
                        }

                        const_cast<Stage&>(*this).CameraFollowSmooth(actor, zoom, responsiveness);
                    }
                    else
                    {
                        const_cast<Stage&>(*this).CameraFollow(actor, zoom);
                    }
                }

                return const_cast<Stage&>(*this);
            }

            if ((name == "setmastervolume" || name == "mastervolume") &&
                !args.empty() &&
                detail::TryParseFloat(args[0], x))
            {
                SetMasterVolume(x);
                return const_cast<Stage&>(*this);
            }

            if ((name == "setbusvolume" || name == "busvolume") &&
                args.size() >= 2 &&
                detail::TryParseFloat(args[1], x))
            {
                SetBusVolume(detail::Unquote(args[0]), x);
                return const_cast<Stage&>(*this);
            }

            if (name == "playsound" && !args.empty())
            {
                if (args.size() >= 2 && detail::TryParseBool(args[1], enabled))
                {
                    PlaySound(detail::Unquote(args[0]), enabled);
                }
                else
                {
                    PlaySound(detail::Unquote(args[0]));
                }

                return const_cast<Stage&>(*this);
            }

            if (name == "playalias" && !args.empty())
            {
                if (args.size() >= 2 && detail::TryParseBool(args[1], enabled))
                {
                    PlayAlias(detail::Unquote(args[0]), enabled);
                }
                else
                {
                    PlayAlias(detail::Unquote(args[0]));
                }

                return const_cast<Stage&>(*this);
            }

            if (name == "playonbus" && args.size() >= 2)
            {
                if (args.size() >= 3 && detail::TryParseBool(args[2], enabled))
                {
                    PlayOnBus(detail::Unquote(args[0]), detail::Unquote(args[1]), enabled);
                }
                else
                {
                    PlayOnBus(detail::Unquote(args[0]), detail::Unquote(args[1]));
                }

                return const_cast<Stage&>(*this);
            }

            if (name == "playmusic" && !args.empty())
            {
                if (args.size() >= 2 && detail::TryParseBool(args[1], enabled))
                {
                    PlayMusic(detail::Unquote(args[0]), enabled);
                }
                else
                {
                    PlayMusic(detail::Unquote(args[0]));
                }

                return const_cast<Stage&>(*this);
            }

            if (name == "playeffect" && !args.empty())
            {
                PlayEffect(detail::Unquote(args[0]));
                return const_cast<Stage&>(*this);
            }

            if (name == "stopaudio")
            {
                StopAudio();
                return const_cast<Stage&>(*this);
            }

            if (name == "stopaudiobus" && !args.empty())
            {
                StopAudioBus(detail::Unquote(args[0]));
                return const_cast<Stage&>(*this);
            }

            if (name == "playtone" &&
                args.size() >= 2 &&
                detail::TryParseInt(args[0], integer))
            {
                int durationMs = 0;
                if (detail::TryParseInt(args[1], durationMs))
                {
                    PlayTone(integer, durationMs);
                }

                return const_cast<Stage&>(*this);
            }

            if (name == "windowopacity" && !args.empty() && detail::TryParseFloat(args[0], x))
            {
                return WindowOpacity(x);
            }

            if (name == "windowborderless")
            {
                if (args.empty())
                {
                    return WindowBorderless(true);
                }

                if (detail::TryParseBool(args[0], enabled))
                {
                    return WindowBorderless(enabled);
                }
            }

            if (name == "windowresizable")
            {
                if (args.empty())
                {
                    return WindowResizable(true);
                }

                if (detail::TryParseBool(args[0], enabled))
                {
                    return WindowResizable(enabled);
                }
            }

            if (name == "windowtopmost")
            {
                if (args.empty())
                {
                    return WindowTopMost(true);
                }

                if (detail::TryParseBool(args[0], enabled))
                {
                    return WindowTopMost(enabled);
                }
            }

            if (name == "windowsize" &&
                args.size() >= 2 &&
                detail::TryParseInt(args[0], integer))
            {
                int height = 0;
                if (detail::TryParseInt(args[1], height))
                {
                    return WindowSize(integer, height);
                }
            }

            if (name == "windowposition" &&
                args.size() >= 2 &&
                detail::TryParseInt(args[0], integer))
            {
                int posY = 0;
                if (detail::TryParseInt(args[1], posY))
                {
                    return WindowPosition(integer, posY);
                }
            }

            if (name == "windowcenter")
            {
                return WindowCenter();
            }

            if (name == "focuswindow" && !args.empty())
            {
                FocusWindow(detail::Unquote(args[0]));
                return const_cast<Stage&>(*this);
            }

            if (name == "closewindow" && !args.empty())
            {
                CloseWindow(detail::Unquote(args[0]));
                return const_cast<Stage&>(*this);
            }

            if (name == "closethiswindow")
            {
                CloseThisWindow();
                return const_cast<Stage&>(*this);
            }

            if (name == "hidethiswindow")
            {
                HideThisWindow();
                return const_cast<Stage&>(*this);
            }

            if (name == "openwindow" && args.size() >= 5)
            {
                const std::string title = detail::Unquote(args[0]);
                int windowWidth = 0;
                int windowHeight = 0;
                int renderWidth = 0;
                int renderHeight = 0;
                if (detail::TryParseInt(args[1], windowWidth) &&
                    detail::TryParseInt(args[2], windowHeight) &&
                    detail::TryParseInt(args[3], renderWidth) &&
                    detail::TryParseInt(args[4], renderHeight))
                {
                    Color clearColor = Color { 16, 18, 28, 255 };
                    if (args.size() > 5)
                    {
                        detail::TryParseColor(args, 5, 1, clearColor, consumed);
                    }

                    OpenWindow(
                        title,
                        windowWidth,
                        windowHeight,
                        renderWidth,
                        renderHeight,
                        [](Stage& blankStage)
                        {
                            blankStage.Background(16, 18, 28);
                        },
                        clearColor,
                        false,
                        true
                    );
                }

                return const_cast<Stage&>(*this);
            }

            return const_cast<Stage&>(*this);
        }

        Stage& hontoCode(const std::string& command) const
        {
            return Code(command);
        }

        void EveryFrame(std::function<void(float)> fn)
        {
            if (m_State == nullptr || fn == nullptr)
            {
                return;
            }

            if (m_Scene != nullptr)
            {
                m_Scene->EveryFrame();
            }

            m_State->updates.push_back(std::move(fn));
        }

        void hontoEveryFrame(std::function<void(float)> fn)
        {
            EveryFrame(std::move(fn));
        }

        void WhenPressed(Key key, std::function<void()> fn)
        {
            EveryFrame(
                [key, fn = std::move(fn)](float)
                {
                    if (Pressed(key) && fn != nullptr)
                    {
                        fn();
                    }
                }
            );
        }

        void hontoWhenPressed(Key key, std::function<void()> fn)
        {
            WhenPressed(key, std::move(fn));
        }

        void WhenClicked(const Actor& actor, std::function<void()> fn, Mouse button = Mouse::Left)
        {
            EveryFrame(
                [actor, button, fn = std::move(fn)](float)
                {
                    if (fn == nullptr || !HonTo::HasMouse())
                    {
                        return;
                    }

                    if (actor.ContainsPoint(HonTo::MousePosition()) && HonTo::MousePressed(button))
                    {
                        fn();
                    }
                }
            );
        }

        void hontoWhenClicked(const Actor& actor, std::function<void()> fn, Mouse button = Mouse::Left)
        {
            WhenClicked(actor, std::move(fn), button);
        }

        void WhenTouching(const Actor& first, const Actor& second, std::function<void()> fn, bool onceEver = false)
        {
            auto wasTouching = std::make_shared<bool>(false);
            auto firedEver = std::make_shared<bool>(false);

            EveryFrame(
                [first, second, fn = std::move(fn), onceEver, wasTouching, firedEver](float)
                {
                    if (fn == nullptr || !first || !second)
                    {
                        return;
                    }

                    const bool touching = first.Touching(second);
                    if (touching && !*wasTouching && (!onceEver || !*firedEver))
                    {
                        fn();
                        *firedEver = true;
                    }

                    *wasTouching = touching;
                }
            );
        }

        void WhileTouching(const Actor& first, const Actor& second, std::function<void(float)> fn)
        {
            EveryFrame(
                [first, second, fn = std::move(fn)](float deltaTime)
                {
                    if (fn == nullptr || !first || !second)
                    {
                        return;
                    }

                    if (first.Touching(second))
                    {
                        fn(deltaTime);
                    }
                }
            );
        }

        void hontoWhenTouching(const Actor& first, const Actor& second, std::function<void()> fn, bool onceEver = false)
        {
            WhenTouching(first, second, std::move(fn), onceEver);
        }

        void hontoWhileTouching(const Actor& first, const Actor& second, std::function<void(float)> fn)
        {
            WhileTouching(first, second, std::move(fn));
        }

        void GoWindow(
            const std::string& windowIdOrTitle,
            std::function<void(Stage&)> setup,
            const Transition& transition = {},
            bool focusWindow = true
        ) const
        {
            honto::Director::Get().ReplaceSceneInWindow(
                windowIdOrTitle,
                std::make_unique<detail::ScriptScene>(std::move(setup)),
                transition,
                focusWindow
            );
        }

        void GoWindowWithFade(
            const std::string& windowIdOrTitle,
            std::function<void(Stage&)> setup,
            float seconds = 0.5f,
            Color color = Color { 0, 0, 0, 255 },
            bool focusWindow = true
        ) const
        {
            GoWindow(windowIdOrTitle, std::move(setup), Fade(seconds, color), focusWindow);
        }

        void FocusWindow(const std::string& windowIdOrTitle) const
        {
            honto::Director::Get().FocusWindow(windowIdOrTitle);
        }

        bool OpenWindow(
            std::string title,
            int windowWidth,
            int windowHeight,
            int renderWidth,
            int renderHeight,
            std::function<void(Stage&)> setup,
            Color clearColor = Color { 16, 18, 28, 255 },
            bool closeStopsGame = false,
            bool focusWindow = true
        ) const
        {
            honto::WindowStartup startup;
            startup.config.title = std::move(title);
            startup.config.windowId = startup.config.title;
            startup.config.windowWidth = windowWidth;
            startup.config.windowHeight = windowHeight;
            startup.config.renderWidth = renderWidth;
            startup.config.renderHeight = renderHeight;
            startup.config.clearColor = clearColor;
            startup.closeStopsGame = closeStopsGame;
            startup.focusWindow = focusWindow;
            startup.createScene = detail::MakeScriptSceneFactory(std::move(setup));
            return honto::Director::Get().OpenWindow(std::move(startup), focusWindow);
        }

        bool CloseWindow(const std::string& windowIdOrTitle) const
        {
            return honto::Director::Get().CloseWindow(windowIdOrTitle);
        }

        bool CloseThisWindow() const
        {
            if (auto* window = honto::Director::Get().GetWindow())
            {
                window->Close();
                return true;
            }

            return false;
        }

        bool HideThisWindow() const
        {
            if (auto* window = honto::Director::Get().GetWindow())
            {
                window->Hide();
                return true;
            }

            return false;
        }

        void hontoGoWindow(
            const std::string& windowIdOrTitle,
            std::function<void(Stage&)> setup,
            const Transition& transition = {},
            bool focusWindow = true
        ) const
        {
            GoWindow(windowIdOrTitle, std::move(setup), transition, focusWindow);
        }

        void hontoGoWindowWithFade(
            const std::string& windowIdOrTitle,
            std::function<void(Stage&)> setup,
            float seconds = 0.5f,
            Color color = Color { 0, 0, 0, 255 },
            bool focusWindow = true
        ) const
        {
            GoWindowWithFade(windowIdOrTitle, std::move(setup), seconds, color, focusWindow);
        }

        void hontoFocusWindow(const std::string& windowIdOrTitle) const
        {
            FocusWindow(windowIdOrTitle);
        }

        bool hontoOpenWindow(
            std::string title,
            int windowWidth,
            int windowHeight,
            int renderWidth,
            int renderHeight,
            std::function<void(Stage&)> setup,
            Color clearColor = Color { 16, 18, 28, 255 },
            bool closeStopsGame = false,
            bool focusWindow = true
        ) const
        {
            return OpenWindow(
                std::move(title),
                windowWidth,
                windowHeight,
                renderWidth,
                renderHeight,
                std::move(setup),
                clearColor,
                closeStopsGame,
                focusWindow
            );
        }

        bool hontoCloseWindow(const std::string& windowIdOrTitle) const
        {
            return CloseWindow(windowIdOrTitle);
        }

        bool hontoCloseThisWindow() const
        {
            return CloseThisWindow();
        }

        bool hontoHideThisWindow() const
        {
            return HideThisWindow();
        }

        void WhilePressing(Key key, std::function<void(float)> fn)
        {
            EveryFrame(
                [key, fn = std::move(fn)](float deltaTime)
                {
                    if (Pressing(key) && fn != nullptr)
                    {
                        fn(deltaTime);
                    }
                }
            );
        }

        void hontoWhilePressing(Key key, std::function<void(float)> fn)
        {
            WhilePressing(key, std::move(fn));
        }

        template <typename TScene>
        void Go() const
        {
            if (m_Scene != nullptr)
            {
                m_Scene->Go<TScene>();
            }
        }

        template <typename TScene>
        void Go(const Transition& transition) const
        {
            if (m_Scene != nullptr)
            {
                m_Scene->Go<TScene>(transition);
            }
        }

        void Go(std::function<void(Stage&)> setup, const Transition& transition = {}) const
        {
            if (m_Scene != nullptr)
            {
                m_Scene->Go(std::make_unique<detail::ScriptScene>(std::move(setup)), transition);
            }
        }

        void GoWithFade(std::function<void(Stage&)> setup, float seconds = 0.5f, Color color = Color { 0, 0, 0, 255 }) const
        {
            Go(std::move(setup), Fade(seconds, color));
        }

        template <typename TScene>
        void GoWithFade(float seconds = 0.5f, Color color = Color { 0, 0, 0, 255 }) const
        {
            Go<TScene>(Fade(seconds, color));
        }

        template <typename TScene>
        void hontoGo() const
        {
            Go<TScene>();
        }

        template <typename TScene>
        void hontoGo(const Transition& transition) const
        {
            Go<TScene>(transition);
        }

        void hontoGo(std::function<void(Stage&)> setup, const Transition& transition = {}) const
        {
            Go(std::move(setup), transition);
        }

        void hontoGoWithFade(std::function<void(Stage&)> setup, float seconds = 0.5f, Color color = Color { 0, 0, 0, 255 }) const
        {
            GoWithFade(std::move(setup), seconds, color);
        }

        template <typename TScene>
        void hontoGoWithFade(float seconds = 0.5f, Color color = Color { 0, 0, 0, 255 }) const
        {
            GoWithFade<TScene>(seconds, color);
        }

    private:
        Actor CreateActor(const std::string& name, const std::shared_ptr<honto::Node>& node)
        {
            if (m_State == nullptr || node == nullptr)
            {
                return {};
            }

            auto actorState = std::make_shared<detail::ActorState>();
            actorState->node = node;
            actorState->stage = m_State;
            actorState->name = name.empty() ? ("actor_" + std::to_string(m_State->nextAnonymousId++)) : name;

            if (!name.empty())
            {
                m_State->namedActors[name] = actorState;
            }

            if (const auto tileMap = std::dynamic_pointer_cast<honto::TileMap>(node))
            {
                m_State->namedTileMaps[actorState->name] = tileMap;
            }

            if (m_Scene != nullptr)
            {
                m_Scene->Add(node);
            }

            return Actor(actorState);
        }

        HonTo::Scene* m_Scene = nullptr;
        std::shared_ptr<detail::StageState> m_State;
    };

    inline bool detail::ScriptScene::Setup()
    {
        Stage stage(this, m_State);

        if (m_Setup != nullptr)
        {
            m_Setup(stage);
        }

        if (m_State != nullptr && !m_State->updates.empty())
        {
            EveryFrame();
        }

        return true;
    }

    inline void detail::ScriptScene::Update(float deltaTime)
    {
        if (m_State == nullptr)
        {
            return;
        }

        const std::size_t callbackCount = m_State->updates.size();
        for (std::size_t index = 0; index < callbackCount; ++index)
        {
            const auto& callback = m_State->updates[index];
            if (callback != nullptr)
            {
                callback(deltaTime);
            }
        }
    }

    namespace detail
    {
        inline std::function<std::unique_ptr<honto::Scene>()> MakeScriptSceneFactory(std::function<void(Stage&)> setup)
        {
            return [setup = std::move(setup)]()
            {
                return std::make_unique<detail::ScriptScene>(setup);
            };
        }
    }

    class GameBuilder
    {
    public:
        GameBuilder()
        {
            m_Config.title = "HonTo Game";
        }

        GameBuilder& Title(std::string title)
        {
            m_Config.title = std::move(title);
            return *this;
        }

        GameBuilder& WindowId(std::string windowId)
        {
            m_Config.windowId = std::move(windowId);
            return *this;
        }

        GameBuilder& Borderless(bool enabled = true)
        {
            m_Config.borderless = enabled;
            return *this;
        }

        GameBuilder& Resizable(bool enabled = true)
        {
            m_Config.resizable = enabled;
            return *this;
        }

        GameBuilder& Opacity(float opacity)
        {
            m_Config.opacity = std::clamp(opacity, 0.1f, 1.0f);
            return *this;
        }

        GameBuilder& TopMost(bool enabled = true)
        {
            m_Config.alwaysOnTop = enabled;
            return *this;
        }

        GameBuilder& hontoTitle(std::string title)
        {
            return Title(std::move(title));
        }

        GameBuilder& hontoWindowId(std::string windowId)
        {
            return WindowId(std::move(windowId));
        }

        GameBuilder& hontoBorderless(bool enabled = true)
        {
            return Borderless(enabled);
        }

        GameBuilder& hontoResizable(bool enabled = true)
        {
            return Resizable(enabled);
        }

        GameBuilder& hontoOpacity(float opacity)
        {
            return Opacity(opacity);
        }

        GameBuilder& hontoTopMost(bool enabled = true)
        {
            return TopMost(enabled);
        }

        GameBuilder& Code(const std::string& command)
        {
            const detail::ParsedCommand parsed = detail::ParseCommand(command);
            if (!parsed.valid)
            {
                return *this;
            }

            const std::string name = detail::NormalizeCommandName(parsed.name);
            const auto& args = parsed.args;

            float number = 0.0f;
            bool enabled = false;
            int width = 0;
            Color color {};
            std::size_t consumed = 0;

            if (name == "title" && !args.empty())
            {
                return Title(detail::Unquote(args[0]));
            }

            if (name == "windowid" && !args.empty())
            {
                return WindowId(detail::Unquote(args[0]));
            }

            if (name == "borderless")
            {
                if (args.empty())
                {
                    return Borderless(true);
                }

                if (detail::TryParseBool(args[0], enabled))
                {
                    return Borderless(enabled);
                }
            }

            if (name == "resizable")
            {
                if (args.empty())
                {
                    return Resizable(true);
                }

                if (detail::TryParseBool(args[0], enabled))
                {
                    return Resizable(enabled);
                }
            }

            if (name == "opacity" && !args.empty() && detail::TryParseFloat(args[0], number))
            {
                return Opacity(number);
            }

            if (name == "topmost")
            {
                if (args.empty())
                {
                    return TopMost(true);
                }

                if (detail::TryParseBool(args[0], enabled))
                {
                    return TopMost(enabled);
                }
            }

            if (name == "window" && args.size() >= 2 && detail::TryParseInt(args[0], width))
            {
                int height = 0;
                if (detail::TryParseInt(args[1], height))
                {
                    return Window(width, height);
                }
            }

            if (name == "render" && args.size() >= 2 && detail::TryParseInt(args[0], width))
            {
                int height = 0;
                if (detail::TryParseInt(args[1], height))
                {
                    return Render(width, height);
                }
            }

            if (name == "clear" &&
                detail::TryParseColor(args, 0, 1, color, consumed) &&
                consumed == args.size())
            {
                return Clear(color);
            }

            if (name == "openwindow" && args.size() >= 5)
            {
                const std::string title = detail::Unquote(args[0]);
                int windowWidth = 0;
                int windowHeight = 0;
                int renderWidth = 0;
                int renderHeight = 0;
                if (detail::TryParseInt(args[1], windowWidth) &&
                    detail::TryParseInt(args[2], windowHeight) &&
                    detail::TryParseInt(args[3], renderWidth) &&
                    detail::TryParseInt(args[4], renderHeight))
                {
                    Color clearColor = Color { 16, 18, 28, 255 };
                    if (args.size() > 5)
                    {
                        detail::TryParseColor(args, 5, 1, clearColor, consumed);
                    }

                    return OpenWindow(
                        title,
                        windowWidth,
                        windowHeight,
                        renderWidth,
                        renderHeight,
                        [](Stage& stage)
                        {
                            stage.Background(16, 18, 28);
                        },
                        clearColor,
                        false
                    );
                }
            }

            return *this;
        }

        GameBuilder& hontoCode(const std::string& command)
        {
            return Code(command);
        }

        GameBuilder& Window(int width, int height)
        {
            m_Config.windowWidth = width;
            m_Config.windowHeight = height;
            return *this;
        }

        GameBuilder& hontoWindow(int width, int height)
        {
            return Window(width, height);
        }

        GameBuilder& Render(int width, int height)
        {
            m_Config.renderWidth = width;
            m_Config.renderHeight = height;
            return *this;
        }

        GameBuilder& hontoRender(int width, int height)
        {
            return Render(width, height);
        }

        GameBuilder& Clear(Color color)
        {
            m_Config.clearColor = color;
            return *this;
        }

        GameBuilder& hontoClear(Color color)
        {
            return Clear(color);
        }

        template <typename TScene>
        GameBuilder& StartWith()
        {
            m_SceneFactory = []()
            {
                return std::make_unique<TScene>();
            };
            return *this;
        }

        template <typename TScene>
        GameBuilder& hontoStartWith()
        {
            return StartWith<TScene>();
        }

        GameBuilder& Play(std::function<void(Stage&)> setup)
        {
            m_SceneFactory = detail::MakeScriptSceneFactory(std::move(setup));
            return *this;
        }

        GameBuilder& hontoPlay(std::function<void(Stage&)> setup)
        {
            return Play(std::move(setup));
        }

        template <typename TScene>
        GameBuilder& OpenWindow(
            std::string title,
            int windowWidth,
            int windowHeight,
            int renderWidth,
            int renderHeight,
            Color clearColor = Color { 16, 18, 28, 255 },
            bool closeStopsGame = false
        )
        {
            detail::BuiltGame::BuiltWindow window;
            window.config.title = std::move(title);
            window.config.windowId = window.config.title;
            window.config.windowWidth = windowWidth;
            window.config.windowHeight = windowHeight;
            window.config.renderWidth = renderWidth;
            window.config.renderHeight = renderHeight;
            window.config.clearColor = clearColor;
            window.config.resizable = m_Config.resizable;
            window.config.borderless = m_Config.borderless;
            window.config.alwaysOnTop = m_Config.alwaysOnTop;
            window.config.opacity = m_Config.opacity;
            window.closeStopsGame = closeStopsGame;
            window.sceneFactory = []()
            {
                return std::make_unique<TScene>();
            };
            m_AdditionalWindows.push_back(std::move(window));
            return *this;
        }

        template <typename TScene>
        GameBuilder& hontoOpenWindow(
            std::string title,
            int windowWidth,
            int windowHeight,
            int renderWidth,
            int renderHeight,
            Color clearColor = Color { 16, 18, 28, 255 },
            bool closeStopsGame = false
        )
        {
            return OpenWindow<TScene>(
                std::move(title),
                windowWidth,
                windowHeight,
                renderWidth,
                renderHeight,
                clearColor,
                closeStopsGame
            );
        }

        GameBuilder& OpenWindow(
            std::string title,
            int windowWidth,
            int windowHeight,
            int renderWidth,
            int renderHeight,
            std::function<void(Stage&)> setup,
            Color clearColor = Color { 16, 18, 28, 255 },
            bool closeStopsGame = false
        )
        {
            detail::BuiltGame::BuiltWindow window;
            window.config.title = std::move(title);
            window.config.windowId = window.config.title;
            window.config.windowWidth = windowWidth;
            window.config.windowHeight = windowHeight;
            window.config.renderWidth = renderWidth;
            window.config.renderHeight = renderHeight;
            window.config.clearColor = clearColor;
            window.config.resizable = m_Config.resizable;
            window.config.borderless = m_Config.borderless;
            window.config.alwaysOnTop = m_Config.alwaysOnTop;
            window.config.opacity = m_Config.opacity;
            window.closeStopsGame = closeStopsGame;
            window.sceneFactory = detail::MakeScriptSceneFactory(std::move(setup));
            m_AdditionalWindows.push_back(std::move(window));
            return *this;
        }

        GameBuilder& hontoOpenWindow(
            std::string title,
            int windowWidth,
            int windowHeight,
            int renderWidth,
            int renderHeight,
            std::function<void(Stage&)> setup,
            Color clearColor = Color { 16, 18, 28, 255 },
            bool closeStopsGame = false
        )
        {
            return OpenWindow(
                std::move(title),
                windowWidth,
                windowHeight,
                renderWidth,
                renderHeight,
                std::move(setup),
                clearColor,
                closeStopsGame
            );
        }

        int Run()
        {
            detail::BuiltGame game(m_Config, m_SceneFactory, m_AdditionalWindows);
            honto::Application application;
            return application.Run(game);
        }

        int hontoRun()
        {
            return Run();
        }

    private:
        honto::AppConfig m_Config {};
        std::function<std::unique_ptr<honto::Scene>()> m_SceneFactory;
        std::vector<detail::BuiltGame::BuiltWindow> m_AdditionalWindows;
    };

    inline GameBuilder Game(const std::string& title = "HonTo Game")
    {
        GameBuilder game;
        game.Title(title);
        return game;
    }
}

namespace honto
{
    using hontoVec2 = Vec2;
    using hontoColor = Color;
    using hontoKey = KeyCode;
    using hontoMouse = MouseButton;
    using hontoTransition = HonTo::Transition;
    using hontoScene = HonTo::Scene;
    using hontoActor = HonTo::Actor;
    using hontoAnimation = HonTo::Animation;
    using hontoFrameAnimation = HonTo::FrameAnimation;
    using hontoLevel = LevelDocument;
    using hontoLevelEntity = LevelEntity;
    using hontoStage = HonTo::Stage;
    using hontoSpriteBuilder = HonTo::Sprite;
    using hontoLayerBuilder = HonTo::Layer;
    using hontoFrameBuilder = HonTo::Frame;
    using hontoGameBuilder = HonTo::GameBuilder;
    using hontoTexture = Texture;
    using hontoTextureRegion = TextureRegion;
    using hontoTileMapActor = HonTo::TileMapActor;
    using hontoParticleActor = HonTo::ParticleActor;
    using hontoRaycastActor = HonTo::RaycastActor;

    inline Color hontoRGBA(std::uint8_t r, std::uint8_t g, std::uint8_t b, std::uint8_t a = 255)
    {
        return HonTo::RGBA(r, g, b, a);
    }

    inline void hontoPrint(const std::string& text)
    {
        HonTo::Print(text);
    }

    inline HonTo::Transition hontoFade(float seconds = 0.5f, Color color = Color { 0, 0, 0, 255 })
    {
        return HonTo::Fade(seconds, color);
    }

    inline HonTo::Sprite hontoBox(float width, float height, Color color)
    {
        return HonTo::Box(width, height, color);
    }

    inline std::shared_ptr<Texture> hontoLoadTexture(const std::string& path)
    {
        return HonTo::LoadTexture(path);
    }

    inline LevelDocument hontoLoadLevel(const std::string& path)
    {
        return HonTo::LoadLevel(path);
    }

    inline bool hontoSaveLevel(const std::string& path, const LevelDocument& level)
    {
        return HonTo::SaveLevel(path, level);
    }

    inline const LevelEntity* hontoFindLevelEntity(const LevelDocument& level, const std::string& name)
    {
        return HonTo::FindLevelEntity(level, name);
    }

    inline std::shared_ptr<Texture> hontoCheckerTexture(
        int width,
        int height,
        Color a,
        Color b,
        int cellSize = 8
    )
    {
        return HonTo::CheckerTexture(width, height, a, b, cellSize);
    }

    inline std::shared_ptr<Texture> hontoFrameSheetTexture(
        int frameWidth,
        int frameHeight,
        const std::vector<Color>& frameColors,
        int columns = 0
    )
    {
        return HonTo::FrameSheetTexture(frameWidth, frameHeight, frameColors, columns);
    }

    inline bool hontoPlaySound(const std::string& path, bool loop = false)
    {
        return HonTo::PlaySound(path, loop);
    }

    inline bool hontoPlayAlias(const std::string& alias, bool loop = false)
    {
        return HonTo::PlayAlias(alias, loop);
    }

    inline bool hontoPlayOnBus(const std::string& bus, const std::string& path, bool loop = false)
    {
        return HonTo::PlayOnBus(bus, path, loop);
    }

    inline bool hontoPlayMusic(const std::string& path, bool loop = true)
    {
        return HonTo::PlayMusic(path, loop);
    }

    inline bool hontoPlayEffect(const std::string& path)
    {
        return HonTo::PlayEffect(path);
    }

    inline void hontoStopAudio()
    {
        HonTo::StopAudio();
    }

    inline void hontoStopAudioBus(const std::string& bus)
    {
        HonTo::StopAudioBus(bus);
    }

    inline void hontoSetMasterVolume(float volume)
    {
        HonTo::SetMasterVolume(volume);
    }

    inline float hontoMasterVolume()
    {
        return HonTo::MasterVolume();
    }

    inline void hontoSetBusVolume(const std::string& bus, float volume)
    {
        HonTo::SetBusVolume(bus, volume);
    }

    inline float hontoBusVolume(const std::string& bus)
    {
        return HonTo::BusVolume(bus);
    }

    inline void hontoPlayTone(int frequency, int durationMs)
    {
        HonTo::PlayTone(frequency, durationMs);
    }

    inline HonTo::Layer hontoFill(float width, float height, Color color)
    {
        return HonTo::Fill(width, height, color);
    }

    inline HonTo::Layer hontoFill(const Vec2& size, Color color)
    {
        return HonTo::Fill(size, color);
    }

    inline HonTo::Frame hontoOutline(float width, float height, Color color, int thickness = 1)
    {
        return HonTo::Outline(width, height, color, thickness);
    }

    inline Vec2 hontoVisibleSize()
    {
        return HonTo::VisibleSize();
    }

    inline bool hontoPressing(KeyCode key)
    {
        return HonTo::Pressing(key);
    }

    inline bool hontoPressed(KeyCode key)
    {
        return HonTo::Pressed(key);
    }

    inline Vec2 hontoMousePosition()
    {
        return HonTo::MousePosition();
    }

    inline bool hontoHasMouse()
    {
        return HonTo::HasMouse();
    }

    inline bool hontoMouseDown(MouseButton button)
    {
        return HonTo::MouseDown(button);
    }

    inline bool hontoMousePressed(MouseButton button)
    {
        return HonTo::MousePressed(button);
    }

    inline HonTo::GameBuilder hontoGame(const std::string& title = "honto Game")
    {
        return HonTo::Game(title);
    }
}
